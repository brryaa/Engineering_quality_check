from html import escape
from html.parser import HTMLParser

from django.core.management.base import BaseCommand

from sitecontent.models import ArticlePage


ALLOWED_TAGS = {"p", "strong", "em", "a", "ul", "ol", "li", "br", "h2", "h3", "blockquote"}


class RichTextSanitizer(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.open_tags = []

    def handle_starttag(self, tag, attrs):
        if tag not in ALLOWED_TAGS:
            return
        if tag == "a":
            href = ""
            for key, value in attrs:
                if key == "href":
                    href = value or ""
                    break
            if href:
                self.parts.append(f'<a href="{escape(href, quote=True)}">')
                self.open_tags.append(tag)
            return
        if tag == "br":
            self.parts.append("<br>")
            return
        self.parts.append(f"<{tag}>")
        self.open_tags.append(tag)

    def handle_endtag(self, tag):
        if tag in self.open_tags:
            while self.open_tags:
                current = self.open_tags.pop()
                self.parts.append(f"</{current}>")
                if current == tag:
                    break

    def handle_data(self, data):
        text = data.replace("\xa0", " ").strip()
        if text:
            self.parts.append(escape(text))

    def get_html(self):
        while self.open_tags:
            self.parts.append(f"</{self.open_tags.pop()}>")
        html = "".join(self.parts)
        return html or "<p></p>"


def sanitize_html(value):
    parser = RichTextSanitizer()
    parser.feed(value or "")
    return parser.get_html()


class Command(BaseCommand):
    help = "Sanitize imported article richtext so Wagtail admin can edit it."

    def add_arguments(self, parser):
        parser.add_argument("--ids", nargs="*", type=int, help="Specific ArticlePage ids to sanitize")

    def handle(self, *args, **options):
        ids = options.get("ids") or []
        queryset = ArticlePage.objects.all()
        if ids:
            queryset = queryset.filter(id__in=ids)

        updated = []
        for page in queryset:
            cleaned_body = sanitize_html(str(page.body))
            if cleaned_body != str(page.body):
                page.body = cleaned_body
                page.save_revision().publish()
                updated.append(page.id)

        self.stdout.write(self.style.SUCCESS(f"Sanitized article pages: {updated}"))
