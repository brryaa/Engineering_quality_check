import re

from django.core.management.base import BaseCommand

from meetings.models import MeetingHandbookPage, MeetingRegistrationPage
from sitecontent.models import ArticlePage, StandardPage


LEGACY_UPLOAD_HOST_PATTERN = re.compile(r"https?://(?:www\.)?daxa\.ltd(?=/wp-content/uploads/)")


class Command(BaseCommand):
    help = "Rewrite legacy daxa.ltd WordPress upload URLs to site-local /wp-content/uploads/ paths."

    def handle(self, *args, **options):
        updated = []
        for model in [ArticlePage, StandardPage, MeetingRegistrationPage, MeetingHandbookPage]:
            for obj in model.objects.all():
                changed_fields = []
                for field in obj._meta.fields:
                    value = getattr(obj, field.name, None)
                    if not isinstance(value, str):
                        continue
                    normalized = LEGACY_UPLOAD_HOST_PATTERN.sub("", value)
                    if normalized != value:
                        setattr(obj, field.name, normalized)
                        changed_fields.append(field.name)
                if changed_fields:
                    obj.save_revision().publish()
                    updated.append((model.__name__, obj.id, getattr(obj, "title", ""), changed_fields))

        self.stdout.write(self.style.SUCCESS(f"Updated {len(updated)} objects."))
        for row in updated:
            self.stdout.write(str(row))
