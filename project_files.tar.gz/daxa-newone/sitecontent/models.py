from django.db import models

from wagtail.admin.panels import FieldPanel
from wagtail.fields import RichTextField
from wagtail.models import Page
from wagtail.search import index


WORKSPACE_PAGE_PROFILES = {
    "research-insights": {
        "eyebrow": "Research",
        "headline": "把主题研究、文章与活动线索组织成长期更新的议题频道。",
        "focus_title": "重点组织方式",
        "focus_points": [
            "围绕能源与气候、汽车与交通、跨文化合作三条主线持续沉淀内容。",
            "把文章、专题页与活动成果整合进同一主题结构，保持清晰的内容脉络。",
            "形成研究专题页、文章聚合页与活动关联页之间的可复用关系。",
        ],
        "delivery_title": "频道内容",
        "delivery_items": [
            "专题观察与研究文章",
            "议题导航页与关联活动入口",
            "访谈、报告与合作内容的主题归档",
        ],
    },
    "energy-climate": {
        "eyebrow": "Focus",
        "headline": "围绕能源转型、气候治理与绿色投资建立可持续更新的主题页。",
        "focus_title": "重点议题",
        "focus_points": [
            "全球与区域能源转型节奏、产业链布局和政策变化。",
            "气候治理框架、可持续金融工具和相关国际合作动态。",
            "能源企业、投资机构与公共部门在转型过程中的协同场景。",
        ],
        "delivery_title": "内容板块",
        "delivery_items": [
            "政策观察与行业研究文章",
            "会议议题、论坛内容与专题材料",
            "可持续投资和 ESG 研究的交叉内容",
        ],
    },
    "auto-transport": {
        "eyebrow": "Focus",
        "headline": "围绕汽车产业、交通体系与区域市场变化整理持续更新的研究页。",
        "focus_title": "重点议题",
        "focus_points": [
            "东南亚及其他重点市场的汽车产业格局、政策与渠道变化。",
            "供应链重组、交通基础设施与新能源转型对行业的影响。",
            "企业出海、区域合作与本地化运营中的关键判断点。",
        ],
        "delivery_title": "内容板块",
        "delivery_items": [
            "市场观察与区域研究文章",
            "企业对标、行业扫描与合作议题梳理",
            "与会议、闭门交流相关的主题聚合内容",
        ],
    },
    "cross-cultural-cooperation": {
        "eyebrow": "Focus",
        "headline": "把跨文化交流与国际合作组织成能够承接项目、活动与研究的主题入口。",
        "focus_title": "重点议题",
        "focus_points": [
            "跨区域合作中的沟通、研究与议题设计。",
            "论坛对话、海外考察和多边交流中的内容支持。",
            "把研究议题、活动组织与合作机制放进同一内容框架。",
        ],
        "delivery_title": "内容板块",
        "delivery_items": [
            "合作主题说明与案例沉淀",
            "与活动频道联动的议题入口",
            "适配国际合作场景的内容组织方式",
        ],
    },
    "capabilities": {
        "eyebrow": "Services",
        "headline": "把能力说明、合作方式与项目入口组织成清晰的服务频道。",
        "focus_title": "能力组织原则",
        "focus_points": [
            "按真实服务方向拆页，形成明确的能力矩阵。",
            "强调研究、咨询、方法和交付形式之间的关系，而不是堆叠营销术语。",
            "让项目咨询、标准制定和行业能力在同一结构中便于理解和访问。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "服务范围与适用场景",
            "研究支持和项目协作方式",
            "与数据、活动、专题研究页的联动入口",
        ],
    },
    "asset-management": {
        "eyebrow": "Capability",
        "headline": "围绕资产配置、研究支持与风险协同，形成面向业务场景的正式能力页。",
        "focus_title": "适用场景",
        "focus_points": [
            "行业与企业基本面研究支持。",
            "组合构建、主题跟踪和量化分析协同。",
            "与风险管理、金融数据页联动的持续研究框架。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "行业扫描与标的研究",
            "策略讨论前的背景材料整理",
            "围绕投资判断的专题跟踪内容",
        ],
    },
    "investment-banking": {
        "eyebrow": "Capability",
        "headline": "把行业情报、尽调支持和交易观察整合成清楚的投行研究协作页。",
        "focus_title": "适用场景",
        "focus_points": [
            "行业扫描、项目背景研究与对标分析。",
            "交易前后的信息梳理、持续跟踪与专题补充。",
            "围绕跨境项目、重点行业和区域市场的辅助研究。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "尽调支持与行业情报整理",
            "项目跟踪和多市场信息汇总",
            "研究材料与专题简报输出",
        ],
    },
    "project-consulting": {
        "eyebrow": "Capability",
        "headline": "把项目咨询扩展成可说明工作过程、协作方式与交付结构的服务页面。",
        "focus_title": "适用场景",
        "focus_points": [
            "项目启动前的诊断、需求澄清和议题搭建。",
            "执行过程中的研究支持、资料整理和方案细化。",
            "复杂议题下把研究、协调与落地节奏结合起来。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "项目研究底稿与结构梳理",
            "专题访谈、材料汇总与方案协同",
            "配合会议、论坛和对外沟通的内容支持",
        ],
    },
    "standards-development": {
        "eyebrow": "Capability",
        "headline": "围绕方法论、标准议题和协作机制，形成正式而清晰的能力说明页。",
        "focus_title": "适用场景",
        "focus_points": [
            "标准议题的研究准备与框架搭建。",
            "多方参与场景中的材料整理和沟通支持。",
            "围绕行业实践、政策要求和落地场景的协同设计。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "标准议题研究和背景资料",
            "参与方协同和讨论材料准备",
            "与活动、研究专题联动的内容沉淀",
        ],
    },
    "data-analytics": {
        "eyebrow": "Data",
        "headline": "把数据库、研究支持与订阅服务整合成清楚的数据与调研频道。",
        "focus_title": "频道组织原则",
        "focus_points": [
            "按研究和使用场景拆分页面，形成清晰的数据服务结构。",
            "把风险、信用、金融数据、ESG 和订阅服务放进同一信息框架中。",
            "让数据页面成为研究频道和能力频道之间的实际连接层。",
        ],
        "delivery_title": "频道内容",
        "delivery_items": [
            "数据方向的能力说明",
            "研究支持与订阅服务入口",
            "与专题研究、项目咨询联动的内容关系",
        ],
    },
    "risk-management": {
        "eyebrow": "Data Service",
        "headline": "围绕信用、供应链与政策变化，构建贴近业务使用场景的风险分析页。",
        "focus_title": "重点分析方向",
        "focus_points": [
            "信用风险、对手方风险与主体基本面变化。",
            "供应链波动、区域市场变化和产业链冲击。",
            "气候政策、监管变化和跨境业务中的不确定因素。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "风险主题研究与判断框架",
            "指标、案例和应用场景说明",
            "与信用评级、金融数据页的组合使用方式",
        ],
    },
    "credit-ratings": {
        "eyebrow": "Data Service",
        "headline": "把评级观点与信用研究组织成能支撑判断和沟通的专题页面。",
        "focus_title": "重点分析方向",
        "focus_points": [
            "主体信用、对手方风险和行业信用环境变化。",
            "评级观点与研究判断之间的对应关系。",
            "与投融资、风险管理和数据分析需求的联动使用。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "信用研究与评级观点整理",
            "围绕具体主体或行业的分析材料",
            "与风险管理页协同的分析入口",
        ],
    },
    "financial-data": {
        "eyebrow": "Data Service",
        "headline": "围绕基础面、估值和并购信息，形成清楚的金融数据能力说明。",
        "focus_title": "重点分析方向",
        "focus_points": [
            "基础面、估值、所有权和交易相关数据。",
            "服务于行业研究、项目分析和对标工作的数据底座。",
            "把数据内容与实际工作方法对应起来，便于理解与使用。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "数据范围与典型使用主题",
            "与研究、咨询工作流的衔接方式",
            "与数据库订阅页互补的服务结构",
        ],
    },
    "esg-solutions": {
        "eyebrow": "Data Service",
        "headline": "把可持续数据与 ESG 研究支持整理成独立而清楚的服务说明页。",
        "focus_title": "重点分析方向",
        "focus_points": [
            "环境、社会、治理三个维度的数据与研究框架。",
            "能源转型、绿色投资和供应链责任等相关议题。",
            "为研究、投资判断和合作项目提供交叉支持。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "ESG 主题研究与指标框架",
            "与能源气候专题页联动的内容结构",
            "支持项目咨询和活动议题设计的底层材料",
        ],
    },
    "database-subscription": {
        "eyebrow": "Data Service",
        "headline": "把数据订阅组织成兼顾产品说明与研究支持的正式入口。",
        "focus_title": "服务结构",
        "focus_points": [
            "订阅对象、数据范围和典型使用场景。",
            "配套研究支持和咨询协作方式。",
            "与金融数据、风险管理和信用评级页的组合关系。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "订阅服务结构与适配对象",
            "数据产品和分析支持的搭配方式",
            "典型应用主题与合作方式",
        ],
    },
    "events": {
        "eyebrow": "Events",
        "headline": "把论坛、会议、闭门会和报名流程组织成完整的活动频道。",
        "focus_title": "频道组织原则",
        "focus_points": [
            "活动介绍、会议报名和会务资料放进一套结构中维护。",
            "活动页既承担报名，也承担议题说明和内容沉淀。",
            "与研究专题页、合作页之间形成内容回流关系。",
        ],
        "delivery_title": "频道内容",
        "delivery_items": [
            "活动频道与类型说明",
            "会议报名和会务手册入口",
            "活动回顾和主题专题入口",
        ],
    },
    "executive-forums": {
        "eyebrow": "Program",
        "headline": "把国际会议与高端论坛扩展成可承接议题、报名与内容沉淀的正式页面。",
        "focus_title": "活动组织方向",
        "focus_points": [
            "国际会议、高端论坛与闭门交流的类型划分。",
            "面向议题设计、参会对象和合作交流的内容组织。",
            "把活动介绍和报名、会务能力连接成闭环。",
        ],
        "delivery_title": "服务内容",
        "delivery_items": [
            "活动类型与参与对象说明",
            "会务页、报名页和活动回顾入口",
            "与研究频道联动的议题沉淀",
        ],
    },
}


class StandardPage(Page):
    parent_page_types = ["home.HomePage", "sitecontent.StandardPage"]
    subpage_types = ["sitecontent.StandardPage"]

    intro = models.TextField(blank=True)
    body = RichTextField(blank=True)

    search_fields = Page.search_fields + [
        index.SearchField("intro"),
        index.SearchField("body"),
    ]

    content_panels = Page.content_panels + [
        FieldPanel("intro"),
        FieldPanel("body"),
    ]

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)

        from sitecontent.models import ArticlePage
        from workspace.models import WorkspaceModule

        context["child_pages"] = [
            child.specific
            for child in Page.objects.live().child_of(self).order_by("path")
        ]
        parent_slug = self.get_parent().slug if self.depth > 2 else ""
        page_profile = dict(WORKSPACE_PAGE_PROFILES.get(self.slug, {}))
        if "focus_points" in page_profile:
            page_profile["focus_points"] = list(page_profile["focus_points"])
        if "delivery_items" in page_profile:
            page_profile["delivery_items"] = list(page_profile["delivery_items"])
        context["page_profile"] = page_profile

        if self.slug == "thinktank":
            context["featured_articles"] = ArticlePage.objects.live().order_by("-date", "-first_published_at")[:3]

        if self.slug == "contact-us":
            context["quick_links"] = [
                {
                    "eyebrow": "Search",
                    "title": "先搜索站内内容",
                    "description": "通过统一搜索快速定位文章、专题页面、活动信息和相关业务入口。",
                    "url": "/search/",
                    "label": "进入搜索",
                },
                {
                    "eyebrow": "Articles",
                    "title": "查看最新文章与研究动态",
                    "description": "研究观察、公开观点与专题内容集中发布，便于持续跟踪重点议题。",
                    "url": "/articles/",
                    "label": "浏览文章",
                },
                {
                    "eyebrow": "Meetings",
                    "title": "会议报名与会务信息",
                    "description": "会议报名、参会信息和会务资料集中在统一入口中查看与使用。",
                    "url": "/conference/",
                    "label": "进入报名",
                },
            ]

        if self.slug == "workspace":
            context["workspace_sections"] = [page.specific for page in Page.objects.live().child_of(self).order_by("path")]
            context["workspace_modules"] = WorkspaceModule.objects.order_by("title")[:9]

        page_actions = []

        if self.slug == "workspace":
            page_actions = [
                {"label": "查看研究频道", "url": "/workspace/research-insights/"},
                {"label": "查看数据频道", "url": "/workspace/data-analytics/"},
                {"label": "查看活动频道", "url": "/workspace/events/"},
            ]
        elif self.slug in {"research-insights", "energy-climate", "auto-transport", "cross-cultural-cooperation"} or parent_slug == "research-insights":
            page_actions = [
                {"label": "浏览文章库", "url": "/articles/"},
                {"label": "查看智库频道", "url": "/thinktank/"},
                {"label": "返回专题频道", "url": "/workspace/"},
            ]
        elif self.slug in {"capabilities", "asset-management", "investment-banking", "project-consulting", "standards-development"} or parent_slug == "capabilities":
            page_actions = [
                {"label": "查看数据与调研", "url": "/workspace/data-analytics/"},
                {"label": "查看活动频道", "url": "/workspace/events/"},
                {"label": "返回专题频道", "url": "/workspace/"},
            ]
        elif self.slug in {"data-analytics", "risk-management", "credit-ratings", "financial-data", "esg-solutions", "database-subscription"} or parent_slug == "data-analytics":
            page_actions = [
                {"label": "查看研究频道", "url": "/workspace/research-insights/"},
                {"label": "查看能力建设", "url": "/workspace/capabilities/"},
                {"label": "返回专题频道", "url": "/workspace/"},
            ]
        elif self.slug in {"events", "executive-forums"} or parent_slug == "events":
            page_actions = [
                {"label": "进入会议报名", "url": "/conference/"},
                {"label": "查看会议手册", "url": "/conference-handbook/"},
                {"label": "返回专题频道", "url": "/workspace/"},
            ]

        context["page_actions"] = page_actions
        if page_profile:
            page_profile["actions"] = page_actions
        return context


class ArticleIndexPage(Page):
    parent_page_types = ["home.HomePage"]
    subpage_types = ["sitecontent.ArticlePage"]

    intro = models.TextField(blank=True)

    content_panels = Page.content_panels + [
        FieldPanel("intro"),
    ]

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)
        context["articles"] = (
            ArticlePage.objects.live()
            .descendant_of(self)
            .order_by("-first_published_at")
        )
        return context


class ArticlePage(Page):
    parent_page_types = ["sitecontent.ArticleIndexPage"]
    subpage_types = []

    date = models.DateField("发布日期")
    summary = models.TextField(blank=True)
    body = RichTextField()

    search_fields = Page.search_fields + [
        index.SearchField("summary"),
        index.SearchField("body"),
    ]

    content_panels = Page.content_panels + [
        FieldPanel("date"),
        FieldPanel("summary"),
        FieldPanel("body"),
    ]
