import json
import logging

from django.conf import settings
from django.core.mail import EmailMultiAlternatives

logger = logging.getLogger(__name__)


def _mask_phone(phone_number):
    if not phone_number or len(phone_number) < 7:
        return phone_number
    return f"{phone_number[:3]}****{phone_number[-4:]}"


def _recipient_list(order):
    recipients = []
    if order.contact_email:
        recipients.append(order.contact_email)
    if not recipients:
        first_participant = order.participants.order_by("sort_order", "id").first()
        if first_participant and first_participant.email:
            recipients.append(first_participant.email)
    return list(dict.fromkeys([email for email in recipients if email]))


def _participant_lines(order):
    lines = []
    for index, participant in enumerate(order.participants.order_by("sort_order", "id"), start=1):
        lines.append(
            f"{index}. {participant.full_name} | 职务：{participant.job_title or '未填写'} | 电话：{participant.phone_number} | 邮箱：{participant.email or '未填写'} | 单位：{participant.organization or '未填写'}"
        )
        if participant.notes:
            lines.append(f"   备注：{participant.notes}")
    return lines


def send_registration_email(order, registration_type):
    recipients = _recipient_list(order)
    if not recipients:
        logger.warning("Skip registration email for %s: no recipient email", order.public_id)
        return False

    status_label = "报名已提交（已支付）" if registration_type == "paid" else "预报名已提交"
    subject = f"【大下科技】{status_label} - {order.page.title} - {order.public_id}"

    body_lines = [
        f"您好，{order.contact_name or '参会人'}：",
        "",
        f"您的{status_label}，以下为报名信息确认：",
        "",
        f"会议名称：{order.page.title}",
        f"订单编号：{order.public_id}",
        f"报名状态：{order.get_order_status_display()}",
        f"支付状态：{order.get_payment_status_display()}",
        f"报名人数：{order.attendee_count} 人",
        f"报名类型：{order.get_registration_type_display()}",
        f"支付渠道：{order.get_payment_channel_display() or '暂未支付'}",
        f"报名金额：￥{order.total_amount_display}",
        f"会议时间：{order.page.meeting_time_text}",
        f"会议地点：{order.page.venue}",
        f"联系单位：{order.organization or '未填写'}",
        f"联系人：{order.contact_name or '未填写'}",
        f"联系电话：{order.contact_phone or '未填写'}",
        f"联系邮箱：{order.contact_email or '未填写'}",
        "",
        "参会人信息：",
    ]
    body_lines.extend(_participant_lines(order) or ["- 无参会人明细"])
    body_lines.extend(
        [
            "",
            f"会务联系电话：{order.page.contact_phone or '未提供'}",
            f"会务邮箱：{order.page.contact_email or '未提供'}",
            "",
            "如您需修改报名信息，请直接回复本邮件或联系会务组。",
            "",
            "大下科技会务组",
        ]
    )
    body = "\n".join(body_lines)

    try:
        message = EmailMultiAlternatives(
            subject=subject,
            body=body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=recipients,
        )
        message.send(fail_silently=False)
        logger.info("Registration email sent for %s to %s", order.public_id, recipients)
        return True
    except Exception:
        logger.exception("Failed to send registration email for %s", order.public_id)
        return False


def send_sms_verification(phone_number, code):
    sms_config = settings.MEETING_SMS_CONFIG
    access_key_id = sms_config.get("access_key_id")
    access_key_secret = sms_config.get("access_key_secret")
    sign_name = sms_config.get("sign_name")
    template_code = sms_config.get("template_code")
    endpoint = sms_config.get("endpoint") or "dysmsapi.aliyuncs.com"

    if not all([access_key_id, access_key_secret, sign_name, template_code]):
        raise RuntimeError("短信服务尚未完成配置。")

    try:
        from alibabacloud_dysmsapi20170525.client import Client as Dysmsapi20170525Client
        from alibabacloud_dysmsapi20170525 import models as dysmsapi_models
        from alibabacloud_tea_openapi import models as open_api_models
        from alibabacloud_tea_util import models as util_models
    except ImportError as exc:
        raise RuntimeError("短信服务依赖尚未安装完成。") from exc

    config = open_api_models.Config(
        access_key_id=access_key_id,
        access_key_secret=access_key_secret,
        endpoint=endpoint,
        connect_timeout=settings.MEETING_SMS_CONNECT_TIMEOUT,
        read_timeout=settings.MEETING_SMS_READ_TIMEOUT,
    )
    client = Dysmsapi20170525Client(config)
    request = dysmsapi_models.SendSmsRequest(
        phone_numbers=phone_number,
        sign_name=sign_name,
        template_code=template_code,
        template_param=json.dumps({"code": code}, ensure_ascii=False),
    )
    runtime = util_models.RuntimeOptions(
        connect_timeout=settings.MEETING_SMS_CONNECT_TIMEOUT,
        read_timeout=settings.MEETING_SMS_READ_TIMEOUT,
        autoretry=settings.MEETING_SMS_MAX_ATTEMPTS > 1,
        max_attempts=settings.MEETING_SMS_MAX_ATTEMPTS,
    )

    try:
        response = client.send_sms_with_options(request, runtime)
    except Exception as exc:
        logger.exception("SMS send failed for %s via %s", _mask_phone(phone_number), endpoint)
        error_text = str(exc)
        if "timed out" in error_text.lower():
            raise RuntimeError("短信网关响应超时，短信可能延迟到达，请稍后查看，未收到再重试。") from exc
        raise RuntimeError(f"短信发送失败：{error_text}") from exc

    body = getattr(response, "body", None)
    result_code = getattr(body, "code", "")
    result_message = getattr(body, "message", "")
    request_id = getattr(body, "request_id", "")
    biz_id = getattr(body, "biz_id", "")

    if result_code != "OK":
        logger.error(
            "SMS provider rejected send for %s, code=%s, message=%s, request_id=%s",
            _mask_phone(phone_number),
            result_code,
            result_message,
            request_id,
        )
        raise RuntimeError(f"短信发送失败：{result_code} {result_message}".strip())

    logger.info(
        "SMS verification sent to %s, request_id=%s, biz_id=%s",
        _mask_phone(phone_number),
        request_id,
        biz_id,
    )
    return True
