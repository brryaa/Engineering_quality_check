from decimal import Decimal
import random

from django.db import models
from django.db.models import Max
from django.utils import timezone

from modelcluster.fields import ParentalKey
from wagtail.admin.panels import FieldPanel, InlinePanel, MultiFieldPanel
from wagtail.fields import RichTextField
from wagtail.models import Orderable, Page


def generate_public_id(prefix):
    return timezone.localtime().strftime("%y%m%d%H%M%S") + f"{random.randint(0, 99):02d}"


def generate_out_trade_no():
    return timezone.localtime().strftime("%y%m%d%H%M%S") + f"{random.randint(0, 999999):06d}"


class MeetingRegistrationPage(Page):
    parent_page_types = ["home.HomePage"]
    subpage_types = []

    intro = models.CharField(max_length=160, default='\u201c\u5e37\u5e44\u5929\u4e0b\u201d\u7cfb\u5217\u62a5\u544a\u4f1a')
    hero_title = models.CharField(max_length=160, default='\u62a5\u540d\u53c2\u4f1a\uff5c\u201c\u5e37\u5e44\u5929\u4e0b\u201d\u80fd\u6e90\u53d1\u5c55\u5f62\u52bf\u4e13\u9898\u62a5\u544a\u4f1a')
    hero_summary = RichTextField(
        features=["bold", "italic", "link"],
        default=(
            "<p>\u5feb\u6765\u53c2\u4f1a 2025\u5e7404\u670827\u65e5 \u5317\u4eac\u4f1a\u8bae\u4e2d\u5fc3 6\u53f7\u697c \u7b2c2\u4f1a\u8bae\u5ba4\u3002</p>"
            "<p>\u7531\u4e2d\u56fd\u4f01\u4e1a\u6539\u9769\u4e0e\u53d1\u5c55\u7814\u7a76\u4f1a\u4e3b\u529e\u3001\u4e2d\u56fd\u77f3\u6cb9\u5927\u5b66\uff08\u5317\u4eac\uff09\u80fd\u6e90\u4ea7\u4e1a\u521b\u65b0\u548c\u8f6c\u578b\u53d1\u5c55\u7814\u7a76\u4e2d\u5fc3\u534f\u529e\u3001"
            "\u5927\u4e0b\u79d1\u6280\uff08\u5317\u4eac\uff09\u6709\u9650\u516c\u53f8\u627f\u529e\u7684\u80fd\u6e90\u53d1\u5c55\u5f62\u52bf\u4e13\u9898\u62a5\u544a\u4f1a\uff0c\u5c06\u9080\u8bf7\u80fd\u6e90\u9886\u57df\u6743\u5a01\u4e13\u5bb6\uff0c\u56f4\u7ed5"
            '\u201c\u5341\u4e94\u4e94\u201d\u80fd\u6e90\u8f6c\u578b\u53d1\u5c55\u9762\u4e34\u7684\u5f62\u52bf\u548c\u4efb\u52a1\u5f00\u5c55\u95ed\u95e8\u4ea4\u6d41\u3002</p>'
        ),
    )
    event_highlight = models.CharField(max_length=160, default="2025\u5e7404\u670827\u65e5  09:00\u201418:00  \u5317\u4eac\u4f1a\u8bae\u4e2d\u5fc3 6\u53f7\u697c \u7b2c2\u4f1a\u8bae\u5ba4")
    meeting_time_text = models.CharField(max_length=120, default="2025\u5e7404\u670827\u65e5\uff08\u5468\u65e5\uff09 09:00-18:00")
    venue = models.CharField(max_length=160, default="\u5317\u4eac\u4f1a\u8bae\u4e2d\u5fc3 6\u53f7\u697c \u7b2c2\u4f1a\u8bae\u5ba4")
    organizer = models.CharField(max_length=120, default="\u5927\u4e0b\u79d1\u6280\uff08\u5317\u4eac\uff09\u6709\u9650\u516c\u53f8")
    contact_phone = models.CharField(max_length=40, blank=True, default="\u5218\u8001\u5e08\uff1a18610079939\uff08\u540c\u5fae\u4fe1\uff09")
    contact_email = models.EmailField(blank=True, default="events@daxa.ltd")
    moderator_name = models.CharField(max_length=80, default="\u5415\u5efa\u4e2d")
    moderator_bio = models.TextField(
        default="\u4e2d\u56fd\u4f01\u4e1a\u6539\u9769\u4e0e\u53d1\u5c55\u7814\u7a76\u4f1a\u9ad8\u7ea7\u7814\u7a76\u5458\n\u4e2d\u56fd\u77f3\u6cb9\u5927\u5b66\uff08\u5317\u4eac\uff09\u7279\u8058\u7814\u7a76\u5458\n\u4e2d\u77f3\u6cb9\u7ecf\u6d4e\u6280\u672f\u7814\u7a76\u9662\u539f\u526f\u9662\u957f"
    )
    moderator_image_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2243633",
    )
    handbook_url = models.URLField(blank=True, default="https://daxa.ltd/conference-handbook/")
    alipay_qr_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2245505",
    )
    wechat_qr_url = models.URLField(blank=True, default="")
    ticket_price = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("2500.00"))
    min_group_size = models.PositiveSmallIntegerField(default=2)
    max_group_size = models.PositiveSmallIntegerField(default=12)
    host_units = RichTextField(
        blank=True,
        default=(
            "<p><strong>\u4e3b\u529e\u5355\u4f4d</strong></p>"
            "<p>\u4e2d\u56fd\u4f01\u4e1a\u6539\u9769\u4e0e\u53d1\u5c55\u7814\u7a76\u4f1a</p>"
            "<p><strong>\u534f\u529e\u5355\u4f4d</strong></p>"
            "<p>\u4e2d\u56fd\u77f3\u6cb9\u5927\u5b66\uff08\u5317\u4eac\uff09\u80fd\u6e90\u4ea7\u4e1a\u521b\u65b0\u548c\u8f6c\u578b\u53d1\u5c55\u7814\u7a76\u4e2d\u5fc3</p>"
            "<p><strong>\u627f\u529e\u5355\u4f4d</strong></p>"
            "<p>\u5927\u4e0b\u79d1\u6280\uff08\u5317\u4eac\uff09\u6709\u9650\u516c\u53f8</p>"
        ),
    )
    agenda = RichTextField(blank=True, default="")
    payment_details = RichTextField(blank=True, default="")
    confirmation_note = RichTextField(blank=True, default="")
    contact_details = RichTextField(blank=True, default="")
    route_guide = RichTextField(blank=True, default="")
    attendance_notice = RichTextField(blank=True, default="")
    invoice_and_hotel_note = RichTextField(blank=True, default="")
    consent_copy = models.TextField(
        default=(
            "\u6839\u636e\u4f1a\u8bae\u8bb0\u5f55\u9700\u6c42\uff0c\u60a8\u77e5\u6089\u5e76\u540c\u610f\uff1a\u4e3b\u529e\u65b9\u3001\u534f\u529e\u65b9\u53ca\u627f\u529e\u65b9\u5c06\u5728\u4f1a\u8bae\u671f\u95f4\u8fdb\u884c\u62cd\u7167\u53ca\u5f71\u50cf\u5f55\u5236\uff0c"
            "\u60a8\u7684\u8096\u50cf\u53ef\u80fd\u51fa\u73b0\u5728\u76f8\u5173\u7d20\u6750\u4e2d\uff0c\u5e76\u6388\u6743\u7528\u4e8e\u4f1a\u8bae\u62a5\u9053\u3001\u6d3b\u52a8\u5ba3\u4f20\u7b49\u5408\u6cd5\u7528\u9014\u3002\u6240\u6709\u5f71\u50cf\u8d44\u6599\u7684\u7248\u6743\u5f52"
            "\u4e3b\u529e\u65b9\u53ca\u76f8\u5173\u5355\u4f4d\u6240\u6709\u3002\u82e5\u60a8\u5bf9\u4e2a\u4eba\u5f71\u50cf\u4f7f\u7528\u6709\u7279\u6b8a\u8981\u6c42\uff0c\u8bf7\u4e8e\u4f1a\u8bae\u524d\u8054\u7cfb\u5ba2\u670d\u3002"
        ),
    )
    success_message = models.CharField(max_length=200, default="\u63d0\u4ea4\u6210\u529f\uff0c\u62a5\u540d\u4fe1\u606f\u5df2\u6536\u5230\u3002")
    privacy_note = models.CharField(
        max_length=200,
        default="\u8bf7\u5148\u5b8c\u6210\u5728\u7ebf\u652f\u4ed8\u786e\u8ba4\uff0c\u518d\u63d0\u4ea4\u6700\u7ec8\u62a5\u540d\u4fe1\u606f\u3002",
    )

    content_panels = Page.content_panels + [
        MultiFieldPanel(
            [
                FieldPanel("intro"),
                FieldPanel("hero_title"),
                FieldPanel("hero_summary"),
                FieldPanel("event_highlight"),
            ],
            heading="\u9875\u9762\u5934\u90e8",
        ),
        MultiFieldPanel(
            [
                FieldPanel("meeting_time_text"),
                FieldPanel("venue"),
                FieldPanel("organizer"),
                FieldPanel("contact_phone"),
                FieldPanel("contact_email"),
                FieldPanel("moderator_name"),
                FieldPanel("moderator_bio"),
                FieldPanel("moderator_image_url"),
                FieldPanel("handbook_url"),
                FieldPanel("ticket_price"),
                FieldPanel("min_group_size"),
                FieldPanel("max_group_size"),
                FieldPanel("alipay_qr_url"),
                FieldPanel("wechat_qr_url"),
                FieldPanel("host_units"),
                FieldPanel("agenda"),
                FieldPanel("payment_details"),
                FieldPanel("confirmation_note"),
                FieldPanel("contact_details"),
                FieldPanel("route_guide"),
                FieldPanel("attendance_notice"),
                FieldPanel("invoice_and_hotel_note"),
                FieldPanel("consent_copy"),
            ],
            heading="\u4f1a\u8bae\u4fe1\u606f",
        ),
        InlinePanel("speaker_profiles", label="\u8bb2\u5e08\u4ecb\u7ecd"),
        MultiFieldPanel(
            [
                FieldPanel("success_message"),
                FieldPanel("privacy_note"),
            ],
            heading="\u8868\u5355\u53cd\u9988",
        ),
    ]

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)
        submitted_orders = self.registration_orders.filter(
            order_status__in=[
                MeetingRegistrationOrder.OrderStatus.SUBMITTED,
                MeetingRegistrationOrder.OrderStatus.PRE_REGISTERED,
            ]
        )
        participant_count = MeetingParticipant.objects.filter(
            order__page=self,
            order__order_status__in=[
                MeetingRegistrationOrder.OrderStatus.SUBMITTED,
                MeetingRegistrationOrder.OrderStatus.PRE_REGISTERED,
            ],
        ).count()
        latest = submitted_orders.aggregate(latest=Max("submitted_at"))["latest"]
        context["submission_count"] = participant_count
        context["latest_submission_at"] = latest
        context["success"] = request.GET.get("submitted") == "1"
        context["pre_registered"] = request.GET.get("pre_registered") == "1"
        context["success_order"] = None
        order_id = request.GET.get("order")
        if (context["success"] or context["pre_registered"]) and order_id:
            context["success_order"] = self.registration_orders.filter(public_id=order_id).first()
        context["group_size_options"] = range(max(2, self.min_group_size), self.max_group_size + 1)
        context["payment_channels"] = MeetingRegistrationOrder.PAYMENT_CHANNEL_CHOICES

        cookie_order_id = request.COOKIES.get("mr_order_id", "")
        existing_order = None
        if cookie_order_id:
            existing_order = self.registration_orders.filter(
                public_id=cookie_order_id,
                order_status__in=[
                    MeetingRegistrationOrder.OrderStatus.SUBMITTED,
                    MeetingRegistrationOrder.OrderStatus.PRE_REGISTERED,
                ],
            ).first()
        context["existing_order"] = existing_order
        return context

    @property
    def ticket_price_display(self):
        return f"{self.ticket_price:.2f}"


def _get_client_ip(request):
    """Extract client IP from request, respecting X-Forwarded-For proxy header."""
    xff = request.META.get("HTTP_X_FORWARDED_FOR")
    if xff:
        return xff.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR", "")


class MeetingRegistrationOrder(models.Model):
    REGISTRATION_TYPE_CHOICES = [
        ("single", "\u5355\u4eba\u62a5\u540d"),
        ("group", "\u96c6\u4f53\u62a5\u540d"),
    ]
    PAYMENT_CHANNEL_CHOICES = [
        ("alipay", "\u652f\u4ed8\u5b9d"),
        ("wechat_pay", "\u5fae\u4fe1\u652f\u4ed8"),
    ]

    class OrderStatus(models.TextChoices):
        DRAFT = "draft", "\u5f85\u63d0\u4ea4"
        SUBMITTED = "submitted", "\u5df2\u63d0\u4ea4"
        PRE_REGISTERED = "pre_registered", "\u9884\u62a5\u540d"
        CANCELLED = "cancelled", "\u5df2\u53d6\u6d88"

    class PaymentStatus(models.TextChoices):
        UNPAID = "unpaid", "\u672a\u53d1\u8d77"
        PENDING = "pending", "\u5f85\u652f\u4ed8"
        PAID = "paid", "\u5df2\u652f\u4ed8"
        FAILED = "failed", "\u652f\u4ed8\u5f02\u5e38"

    page = models.ForeignKey(MeetingRegistrationPage, related_name="registration_orders", on_delete=models.CASCADE)
    public_id = models.CharField(max_length=20, unique=True, editable=False)
    out_trade_no = models.CharField(max_length=40, unique=True, editable=False)
    registration_type = models.CharField(max_length=16, choices=REGISTRATION_TYPE_CHOICES, default="single")
    attendee_count = models.PositiveSmallIntegerField(default=1)
    organization = models.CharField("\u516c\u53f8 / \u5355\u4f4d", max_length=160, blank=True)
    contact_name = models.CharField("\u8054\u7cfb\u4eba", max_length=80, blank=True)
    contact_phone = models.CharField("\u8054\u7cfb\u7535\u8bdd", max_length=40, blank=True)
    contact_email = models.EmailField("\u8054\u7cfb\u90ae\u7bb1", blank=True)
    invoice_title = models.CharField("\u5f00\u7968\u62ac\u5934", max_length=160, blank=True)
    invoice_tax_number = models.CharField("\u5f00\u7968\u7a0e\u53f7", max_length=80, blank=True)
    notes = models.TextField("\u5907\u6ce8", blank=True)
    payment_channel = models.CharField("\u652f\u4ed8\u6e20\u9053", max_length=20, choices=PAYMENT_CHANNEL_CHOICES, blank=True)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("2500.00"))
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("2500.00"))
    paid_amount = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0.00"))
    order_status = models.CharField(max_length=20, choices=OrderStatus.choices, default=OrderStatus.DRAFT)
    payment_status = models.CharField(max_length=20, choices=PaymentStatus.choices, default=PaymentStatus.UNPAID)
    payment_provider_trade_no = models.CharField(max_length=80, blank=True)
    payment_qr_payload = models.TextField(blank=True)
    payment_response = models.JSONField(default=dict, blank=True)
    payment_checked_at = models.DateTimeField(null=True, blank=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    submitted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)
    client_ip = models.CharField("\u63d0\u4ea4IP", max_length=45, blank=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "\u4f1a\u8bae\u62a5\u540d\u8ba2\u5355"
        verbose_name_plural = "\u4f1a\u8bae\u62a5\u540d\u8ba2\u5355"

    def __str__(self):
        return f"{self.public_id} - {self.organization}"

    def save(self, *args, **kwargs):
        if not self.public_id:
            while True:
                candidate = generate_public_id("MR")
                if not MeetingRegistrationOrder.objects.filter(public_id=candidate).exists():
                    self.public_id = candidate
                    break
        if not self.out_trade_no:
            while True:
                candidate = generate_out_trade_no()
                if not MeetingRegistrationOrder.objects.filter(out_trade_no=candidate).exists():
                    self.out_trade_no = candidate
                    break
        super().save(*args, **kwargs)

    @property
    def outstanding_amount(self):
        return max(self.total_amount - self.paid_amount, Decimal("0.00"))

    @property
    def total_amount_fen(self):
        return int((self.total_amount * Decimal("100")).quantize(Decimal("1")))

    @property
    def outstanding_amount_fen(self):
        return int((self.outstanding_amount * Decimal("100")).quantize(Decimal("1")))

    @property
    def total_amount_display(self):
        return f"{self.total_amount:.2f}"

    @property
    def paid_amount_display(self):
        return f"{self.paid_amount:.2f}"

    @property
    def outstanding_amount_display(self):
        return f"{self.outstanding_amount:.2f}"


class MeetingParticipant(models.Model):
    INVOICE_TITLE_CHOICES = [
        ("same_as_org", "\u5f00\u7968\u62ac\u5934\u540c\u5355\u4f4d/\u516c\u53f8\u540d"),
        ("see_notes", "\u5f00\u7968\u62ac\u5934\u89c1\u5907\u6ce8"),
    ]

    order = models.ForeignKey(MeetingRegistrationOrder, related_name="participants", on_delete=models.CASCADE)
    sort_order = models.PositiveSmallIntegerField(default=1)
    full_name = models.CharField("\u59d3\u540d", max_length=80)
    phone_number = models.CharField("\u8054\u7cfb\u7535\u8bdd", max_length=40)
    email = models.EmailField("\u90ae\u7bb1", blank=True)
    department = models.CharField("\u90e8\u95e8", max_length=120, blank=True)
    job_title = models.CharField("\u804c\u52a1", max_length=120, blank=True)
    organization = models.CharField("\u5355\u4f4d/\u516c\u53f8", max_length=160, blank=True)
    invoice_tax_number = models.CharField("\u5f00\u7968\u7a0e\u53f7", max_length=80, blank=True)
    invoice_title_choice = models.CharField(
        "\u5f00\u7968\u62ac\u5934\u9009\u62e9",
        max_length=20,
        choices=INVOICE_TITLE_CHOICES,
        default="same_as_org",
    )
    notes = models.TextField("\u5907\u6ce8", blank=True)
    avatar_photo = models.ImageField("\u5934\u50cf\u7167", upload_to="meeting-avatars/", blank=True)
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["sort_order", "id"]
        verbose_name = "\u62a5\u540d\u4eba"
        verbose_name_plural = "\u62a5\u540d\u4eba"

    def __str__(self):
        return f"{self.full_name} - {self.order.public_id}"


class SpeakerProfile(Orderable):
    page = ParentalKey(
        MeetingRegistrationPage,
        related_name="speaker_profiles",
        on_delete=models.CASCADE,
    )
    session_time = models.CharField("\u573a\u6b21\u65f6\u95f4", max_length=40)
    topic = models.CharField("\u8bae\u9898", max_length=160)
    speaker_name = models.CharField("\u8bb2\u5e08\u59d3\u540d", max_length=80)
    speaker_bio = models.TextField("\u8bb2\u5e08\u4ecb\u7ecd")
    image_url = models.URLField("\u5934\u50cf\u5730\u5740", blank=True)

    panels = [
        FieldPanel("session_time"),
        FieldPanel("topic"),
        FieldPanel("speaker_name"),
        FieldPanel("speaker_bio"),
        FieldPanel("image_url"),
    ]

    class Meta:
        ordering = ["sort_order"]
        verbose_name = "\u8bb2\u5e08\u4ecb\u7ecd"
        verbose_name_plural = "\u8bb2\u5e08\u4ecb\u7ecd"

    def __str__(self):
        return f"{self.session_time} {self.speaker_name}"


class MeetingHandbookPage(Page):
    """Meeting handbook page - defaults are stored in the database already."""
    parent_page_types = ["home.HomePage"]
    subpage_types = []

    intro = models.CharField(max_length=120, default="\u4f1a\u8bae\u624b\u518c")
    title_text = models.CharField(max_length=160, default='\u201c\u5e37\u5e44\u5929\u4e0b\u201d\u80fd\u6e90\u53d1\u5c55\u5f62\u52bf\u4e13\u9898\u62a5\u544a\u4f1a \u4f1a\u8bae\u624b\u518c')
    summary = RichTextField(blank=True, default="")
    hero_image_one_url = models.CharField(
        max_length=500,
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2263474",
    )
    hero_image_two_url = models.CharField(
        max_length=500,
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2256824",
    )
    hero_image_three_url = models.CharField(
        max_length=500,
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2243059",
    )
    checkin_time = models.CharField(max_length=80, default="\u7b7e\u5230\u65f6\u95f4\uff1a08:00\u201409:00")
    checkin_details = RichTextField(blank=True, default="")
    morning_agenda = RichTextField(blank=True, default="")
    lunch_details = RichTextField(blank=True, default="")
    afternoon_agenda = RichTextField(blank=True, default="")
    transportation_details = RichTextField(blank=True, default="")
    notice_details = RichTextField(blank=True, default="")
    catering_details = RichTextField(blank=True, default="")
    invoice_details = RichTextField(blank=True, default="")
    hotel_details = RichTextField(blank=True, default="")
    support_details = RichTextField(blank=True, default="")
    support_image_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2256855",
    )
    location_label = models.CharField(max_length=120, default="\u5317\u4eac\u4f1a\u8bae\u4e2d\u5fc3 6\u53f7\u697c\uff08\u9760\u8fd1\u5317\u95e8\uff09")
    map_image_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2256825",
    )
    registration_url = models.URLField(blank=True, default="https://daxa.ltd/conference/")
    home_url = models.URLField(blank=True, default="https://daxa.ltd/")

    content_panels = Page.content_panels + [
        MultiFieldPanel(
            [
                FieldPanel("intro"),
                FieldPanel("title_text"),
                FieldPanel("summary"),
                FieldPanel("hero_image_one_url"),
                FieldPanel("hero_image_two_url"),
                FieldPanel("hero_image_three_url"),
                FieldPanel("checkin_time"),
                FieldPanel("checkin_details"),
                FieldPanel("morning_agenda"),
                FieldPanel("lunch_details"),
                FieldPanel("afternoon_agenda"),
                FieldPanel("transportation_details"),
                FieldPanel("notice_details"),
                FieldPanel("catering_details"),
                FieldPanel("invoice_details"),
                FieldPanel("hotel_details"),
                FieldPanel("support_details"),
                FieldPanel("support_image_url"),
                FieldPanel("location_label"),
                FieldPanel("map_image_url"),
                FieldPanel("registration_url"),
                FieldPanel("home_url"),
            ],
            heading="\u4f1a\u8bae\u624b\u518c\u5185\u5bb9",
        ),
    ]


class SmsVerificationCode(models.Model):
    """SMS verification code records (framework-level, pending actual SMS service integration)."""
    phone_number = models.CharField("\u624b\u673a\u53f7", max_length=40, db_index=True)
    code = models.CharField("\u9a8c\u8bc1\u7801", max_length=8)
    created_at = models.DateTimeField(auto_now_add=True)
    used = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "\u77ed\u4fe1\u9a8c\u8bc1\u7801"
        verbose_name_plural = "\u77ed\u4fe1\u9a8c\u8bc1\u7801"

    def __str__(self):
        return f"{self.phone_number} - {self.code}"


class PaymentWebhookEvent(models.Model):
    """Stores incoming payment notification events pushed from iOS Shortcuts / SMS."""

    received_at = models.DateTimeField(default=timezone.now, db_index=True)
    source = models.CharField("来源", max_length=80, blank=True, default="ios_shortcut")

    # 核心收款字段（由 iOS 快捷指令解析后推送）
    amount = models.CharField("金额", max_length=40, blank=True)
    payer = models.CharField("付款方", max_length=160, blank=True)
    payment_channel = models.CharField("支付渠道", max_length=40, blank=True)   # alipay / wechat / bank
    remark = models.CharField("备注/摘要", max_length=255, blank=True)
    trade_no = models.CharField("交易号", max_length=120, blank=True)
    sms_body = models.TextField("原始短信内容", blank=True)

    # 关联订单（可选，人工或自动匹配）
    matched_order = models.ForeignKey(
        MeetingRegistrationOrder,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="webhook_events",
        verbose_name="匹配订单",
    )

    # 原始 payload（保留完整请求体，便于调试）
    raw_payload = models.JSONField("原始数据", default=dict, blank=True)
    client_ip = models.CharField("来源IP", max_length=45, blank=True)
    processed = models.BooleanField("已处理", default=False)

    class Meta:
        ordering = ["-received_at"]
        verbose_name = "收款通知"
        verbose_name_plural = "收款通知"

    def __str__(self):
        return f"{self.received_at:%Y-%m-%d %H:%M:%S} ¥{self.amount} {self.payer}"
