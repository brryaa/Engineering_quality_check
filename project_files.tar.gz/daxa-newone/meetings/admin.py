import csv

from django.contrib import admin
from django.http import HttpResponse

from .models import MeetingParticipant, MeetingRegistrationOrder, SmsVerificationCode


class MeetingParticipantInline(admin.TabularInline):
    model = MeetingParticipant
    extra = 0
    readonly_fields = (
        'sort_order', 'full_name', 'phone_number', 'email',
        'department', 'job_title', 'organization',
        'invoice_tax_number', 'invoice_title_choice', 'notes',
        'avatar_photo', 'created_at',
    )
    can_delete = False


@admin.register(MeetingRegistrationOrder)
class MeetingRegistrationOrderAdmin(admin.ModelAdmin):
    list_display = (
        'public_id',
        'organization',
        'attendee_count',
        'contact_name',
        'payment_channel',
        'payment_status',
        'order_status',
        'total_amount',
        'client_ip',
        'created_at',
    )
    list_filter = ('payment_channel', 'payment_status', 'order_status', 'created_at')
    search_fields = ('public_id', 'organization', 'contact_name', 'contact_phone', 'contact_email', 'out_trade_no', 'client_ip')
    readonly_fields = (
        'public_id', 'out_trade_no', 'registration_type', 'attendee_count', 'organization', 'contact_name', 'contact_phone', 'contact_email',
        'invoice_title', 'invoice_tax_number', 'notes', 'payment_channel', 'unit_price', 'total_amount', 'order_status', 'payment_status',
        'payment_provider_trade_no', 'payment_qr_payload', 'payment_response', 'payment_checked_at', 'paid_at', 'submitted_at',
        'created_at', 'updated_at', 'client_ip',
    )
    inlines = [MeetingParticipantInline]
    actions = ('export_as_csv',)

    @admin.action(description='导出选中订单及报名人为 CSV')
    def export_as_csv(self, request, queryset):
        response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
        response['Content-Disposition'] = 'attachment; filename="meeting-registration-orders.csv"'
        writer = csv.writer(response)
        writer.writerow([
            '订单号', '报名类型', '单位', '联系人', '联系电话', '联系邮箱',
            '支付渠道', '支付状态', '订单状态', '单价', '总金额', '提交IP',
            '报名人序号', '报名人姓名', '报名人电话', '报名人邮箱',
            '部门', '职位', '报名人单位', '开票税号', '开票抬头选择', '备注',
            '提交时间',
        ])
        for order in queryset.prefetch_related('participants'):
            participants = list(order.participants.all()) or [None]
            for participant in participants:
                writer.writerow([
                    order.public_id,
                    order.get_registration_type_display(),
                    order.organization,
                    order.contact_name,
                    order.contact_phone,
                    order.contact_email,
                    order.get_payment_channel_display() if order.payment_channel else '',
                    order.get_payment_status_display(),
                    order.get_order_status_display(),
                    order.unit_price,
                    order.total_amount,
                    order.client_ip,
                    participant.sort_order if participant else '',
                    participant.full_name if participant else '',
                    participant.phone_number if participant else '',
                    participant.email if participant else '',
                    participant.department if participant else '',
                    participant.job_title if participant else '',
                    participant.organization if participant else '',
                    participant.invoice_tax_number if participant else '',
                    participant.get_invoice_title_choice_display() if participant else '',
                    participant.notes if participant else '',
                    (order.submitted_at or order.created_at).isoformat(),
                ])
        return response


@admin.register(SmsVerificationCode)
class SmsVerificationCodeAdmin(admin.ModelAdmin):
    list_display = ('phone_number', 'code', 'used', 'created_at')
    list_filter = ('used', 'created_at')
    search_fields = ('phone_number',)
    readonly_fields = ('phone_number', 'code', 'created_at', 'used')
