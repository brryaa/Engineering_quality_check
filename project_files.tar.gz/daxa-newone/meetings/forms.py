import re
from django import forms
from django.core.exceptions import ValidationError


AVATAR_MAX_BYTES = 1 * 1024 * 1024
REGISTRATION_TYPE_CHOICES = [
    ("single", "单人报名"),
    ("group", "集体报名"),
]
PAYMENT_CHANNEL_CHOICES = [
    ("alipay", "支付宝"),
    ("wechat_pay", "微信支付"),
]
INVOICE_TITLE_CHOICES = [
    ("same_as_org", "开票抬头同单位/公司名"),
    ("see_notes", "开票抬头见备注"),
]


def validate_file_size(upload, *, max_bytes, label):
    if upload and upload.size > max_bytes:
        limit_kb = max_bytes // 1024
        raise ValidationError(f"{label}不能超过 {limit_kb} KB。")


class MeetingRegistrationOrderForm(forms.Form):
    """Simplified order form — organization/invoice details are now per-participant."""
    page_id = forms.IntegerField(widget=forms.HiddenInput())
    draft_order_id = forms.CharField(required=False, max_length=20)
    registration_type = forms.ChoiceField(choices=REGISTRATION_TYPE_CHOICES, required=False)
    attendee_count = forms.IntegerField(min_value=1, max_value=20)
    payment_channel = forms.ChoiceField(choices=PAYMENT_CHANNEL_CHOICES, required=False)
    consent_acknowledged = forms.BooleanField(required=True)

    def clean(self):
        cleaned_data = super().clean()
        registration_type = cleaned_data.get("registration_type")
        attendee_count = cleaned_data.get("attendee_count") or 1
        if registration_type == "single":
            cleaned_data["attendee_count"] = 1
        elif attendee_count < 2:
            pass  # Auto-derived, no enforcement needed
        return cleaned_data


class PreRegistrationForm(forms.Form):
    """Form for pre-registration (skip payment)."""
    page_id = forms.IntegerField(widget=forms.HiddenInput())
    draft_order_id = forms.CharField(required=False, max_length=20)
    attendee_count = forms.IntegerField(min_value=1, max_value=20)
    consent_acknowledged = forms.BooleanField(required=True)


def build_participants(post, files, attendee_count):
    """Build participant list from POST data with per-participant fields."""
    participants = []
    errors = []
    for index in range(attendee_count):
        prefix = f"attendees-{index}"
        number = index + 1
        participant = {
            "full_name": (post.get(f"{prefix}-full_name") or "").strip(),
            "job_title": (post.get(f"{prefix}-job_title") or "").strip(),
            "phone_number": (post.get(f"{prefix}-phone_number") or "").strip(),
            "email": (post.get(f"{prefix}-email") or "").strip(),
            "organization": (post.get(f"{prefix}-organization") or "").strip(),
            "invoice_tax_number": (post.get(f"{prefix}-invoice_tax_number") or "").strip(),
            "invoice_title_choice": (post.get(f"{prefix}-invoice_title_choice") or "").strip(),
            "notes": (post.get(f"{prefix}-notes") or "").strip(),
            "department": (post.get(f"{prefix}-department") or "").strip(),
            "avatar_photo": files.get(f"{prefix}-avatar_photo"),
        }
        # Required fields
        if not participant["full_name"]:
            errors.append(f"第 {number} 位参会人的姓名不能为空。")
        if not participant["job_title"]:
            errors.append(f"第 {number} 位参会人的职务不能为空。")
        if not participant["phone_number"]:
            errors.append(f"第 {number} 位参会人的联系电话不能为空。")
        elif not re.match(r"^1[3-9]\d{9}$", participant["phone_number"]):
            errors.append(f"第 {number} 位参会人的联系电话格式不正确。")
        if not participant["email"]:
            errors.append(f"第 {number} 位参会人的邮箱不能为空。")
        elif not re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", participant["email"]):
            errors.append(f"第 {number} 位参会人的邮箱格式不正确。")
        if not participant["organization"]:
            errors.append(f"第 {number} 位参会人的单位/公司不能为空。")
        # Invoice title choice is required (radio, must pick one)
        if participant["invoice_title_choice"] not in ("same_as_org", "see_notes"):
            errors.append(f"第 {number} 位参会人请选择开票抬头方式。")
        # Avatar size check
        if participant["avatar_photo"]:
            try:
                validate_file_size(participant["avatar_photo"], max_bytes=AVATAR_MAX_BYTES, label=f"第 {number} 位参会人的头像照")
            except ValidationError as exc:
                errors.extend(exc.messages)
        participants.append(participant)
    return participants, errors
