import base64
import io
import json
import logging
import secrets
import time
from decimal import Decimal
from pathlib import Path
from urllib.parse import quote_plus

import qrcode
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from django.conf import settings


logger = logging.getLogger(__name__)


class PaymentConfigurationError(Exception):
    pass


class PaymentGatewayError(Exception):
    pass


def _load_secret(value, path_value):
    if value:
        return value.replace('\\n', '\n').strip()
    if path_value:
        return Path(path_value).read_text(encoding='utf-8').strip()
    return ""


def _qr_data_url(payload):
    image = qrcode.make(payload)
    buffer = io.BytesIO()
    image.save(buffer, format='PNG')
    encoded = base64.b64encode(buffer.getvalue()).decode('ascii')
    return f"data:image/png;base64,{encoded}"


def _payment_base_url():
    config = settings.MEETING_PAYMENT_CONFIG
    return (config.get('base_url') or settings.WAGTAILADMIN_BASE_URL).rstrip('/')


def _normalize_alipay_key(value, *, private):
    if not value:
        return value
    value = value.strip()
    if 'BEGIN' in value:
        return value
    header = 'PRIVATE KEY' if private else 'PUBLIC KEY'
    body = ''.join(value.split())
    lines = [body[i:i+64] for i in range(0, len(body), 64)]
    return f"-----BEGIN {header}-----\n" + "\n".join(lines) + f"\n-----END {header}-----"


def _alipay_sign_params(params):
    from Cryptodome.Hash import SHA256
    from Cryptodome.PublicKey import RSA
    from Cryptodome.Signature import PKCS1_v1_5

    config = settings.MEETING_PAYMENT_CONFIG
    private_key = _normalize_alipay_key(_load_secret(config.get('alipay_private_key'), config.get('alipay_private_key_path')), private=True)
    key = RSA.import_key(private_key)
    ordered = sorted((k, v) for k, v in params.items() if v is not None and v != '')
    unsigned = '&'.join(f'{k}={v}' for k, v in ordered)
    signer = PKCS1_v1_5.new(key)
    signature = signer.sign(SHA256.new(unsigned.encode('utf-8')))
    sign = base64.encodebytes(signature).decode().replace('\n', '')
    signed = ordered + [('sign', sign)]
    return '&'.join(f'{k}={quote_plus(str(v))}' for k, v in signed)


def _alipay_gateway_params(order, *, method):
    config = settings.MEETING_PAYMENT_CONFIG
    base_url = _payment_base_url()
    biz_content = json.dumps({
        'subject': '帷幄天下系列会议注册费',
        'out_trade_no': order.out_trade_no,
        'total_amount': str(order.outstanding_amount.quantize(Decimal('0.00'))),
        'product_code': 'QUICK_WAP_PAY' if method == 'alipay.trade.wap.pay' else 'FAST_INSTANT_TRADE_PAY',
    }, ensure_ascii=False, separators=(',', ':'))
    return {
        'app_id': config.get('alipay_app_id'),
        'method': method,
        'charset': 'utf-8',
        'sign_type': 'RSA2',
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        'version': '1.0',
        'notify_url': config.get('alipay_notify_url') or f'{base_url}/conference/api/payment/alipay-notify/',
        'return_url': config.get('alipay_return_url') or f'{base_url}/conference/api/payment/alipay-return/',
        'biz_content': biz_content,
    }


def _alipay_client():
    from alipay import AliPay

    config = settings.MEETING_PAYMENT_CONFIG
    app_id = config.get('alipay_app_id')
    private_key = _normalize_alipay_key(_load_secret(config.get('alipay_private_key'), config.get('alipay_private_key_path')), private=True)
    public_key = _normalize_alipay_key(_load_secret(config.get('alipay_public_key'), config.get('alipay_public_key_path')), private=False)
    if not (app_id and private_key and public_key):
        raise PaymentConfigurationError('支付宝参数未配置完整，请先填写 APP ID、应用私钥和支付宝公钥。')
    return AliPay(
        appid=app_id,
        app_notify_url=config.get('alipay_notify_url') or f"{_payment_base_url()}/conference/api/payment/alipay-notify/",
        app_private_key_string=private_key,
        alipay_public_key_string=public_key,
        sign_type='RSA2',
        debug=config.get('alipay_debug', False),
    )


def _wechat_client():
    from wechatpayv3 import WeChatPay, WeChatPayType

    config = settings.MEETING_PAYMENT_CONFIG
    private_key = _load_secret(config.get('wechat_private_key'), config.get('wechat_private_key_path'))
    public_key = _load_secret(config.get('wechat_public_key'), config.get('wechat_public_key_path'))
    public_key_id = config.get('wechat_public_key_id')
    if not all([
        config.get('wechat_mchid'),
        config.get('wechat_appid'),
        config.get('wechat_cert_serial_no'),
        config.get('wechat_apiv3_key'),
        private_key,
    ]):
        raise PaymentConfigurationError('微信支付参数未配置完整，请先填写商户号、应用 ID、证书序列号、APIv3 Key 和商户私钥。')
    cert_dir = config.get('wechat_cert_dir') or '/tmp/wechatpay-certs'
    Path(cert_dir).mkdir(parents=True, exist_ok=True)
    return WeChatPay(
        wechatpay_type=WeChatPayType.NATIVE,
        mchid=config.get('wechat_mchid'),
        private_key=private_key,
        cert_serial_no=config.get('wechat_cert_serial_no'),
        apiv3_key=config.get('wechat_apiv3_key'),
        appid=config.get('wechat_appid'),
        notify_url=config.get('wechat_notify_url') or f"{_payment_base_url()}/conference/api/payment/wechat-notify/",
        cert_dir=cert_dir,
        public_key=public_key or None,
        public_key_id=public_key_id or None,
        partner_mode=False,
    )


def create_payment(order, *, wechat_mode='native', openid='', client_ip='', alipay_mode='page'):
    if order.payment_channel == 'alipay':
        return _create_alipay_payment(order, mode=alipay_mode)
    if order.payment_channel == 'wechat_pay':
        return _create_wechat_payment(order, mode=wechat_mode, openid=openid, client_ip=client_ip)
    raise PaymentGatewayError('暂不支持该支付渠道。')


def query_payment(order):
    if order.payment_channel == 'alipay':
        return _query_alipay_payment(order)
    if order.payment_channel == 'wechat_pay':
        return _query_wechat_payment(order)
    raise PaymentGatewayError('暂不支持该支付渠道。')


def _create_alipay_payment(order, *, mode='page'):
    if mode == 'wap':
        return {
            'channel': 'alipay',
            'payment_mode': 'alipay_external',
            'action_url': 'https://qr.alipay.com/45t111548ewnriuz0p9xm0d',
            'message': '请点击下方按钮打开支付宝支付',
            'raw': {}
        }
    method = 'alipay.trade.wap.pay' if mode == 'wap' else 'alipay.trade.page.pay'
    params = _alipay_gateway_params(order, method=method)
    signed = _alipay_sign_params(params)
    pay_url = f'https://openapi.alipay.com/gateway.do?{signed}'
    return {
        'channel': 'alipay',
        'payment_mode': 'alipay_page' if mode == 'page' else 'alipay_wap',
        'action_url': pay_url,
        'raw': {'signed': signed, 'params': params},
    }
    return {
        'channel': 'alipay',
        'payment_mode': 'alipay_wap' if mode == 'wap' else 'alipay_page',
        'action_url': pay_url,
        'raw': {'signed': signed, 'params': params},
    }


def _query_alipay_payment(order):
    client = _alipay_client()
    response = client.api_alipay_trade_query(out_trade_no=order.out_trade_no)
    trade_status = response.get('trade_status')
    return {
        'paid': trade_status in {'TRADE_SUCCESS', 'TRADE_FINISHED'},
        'trade_no': response.get('trade_no', ''),
        'status_text': trade_status or response.get('msg') or 'WAIT_BUYER_PAY',
        'raw': response,
    }


def _wechat_private_key_string():
    config = settings.MEETING_PAYMENT_CONFIG
    private_key = _load_secret(config.get('wechat_private_key'), config.get('wechat_private_key_path'))
    if not private_key:
        raise PaymentConfigurationError('微信支付商户私钥未配置。')
    return private_key


def _build_wechat_jsapi_params(prepay_id):
    config = settings.MEETING_PAYMENT_CONFIG
    app_id = config.get('wechat_appid')
    nonce_str = secrets.token_hex(16)
    timestamp = str(int(time.time()))
    package = f'prepay_id={prepay_id}'
    message = f'{app_id}\n{timestamp}\n{nonce_str}\n{package}\n'
    private_key = serialization.load_pem_private_key(_wechat_private_key_string().encode('utf-8'), password=None)
    signature = private_key.sign(message.encode('utf-8'), padding.PKCS1v15(), hashes.SHA256())
    pay_sign = base64.b64encode(signature).decode('ascii')
    return {
        'appId': app_id,
        'timeStamp': timestamp,
        'nonceStr': nonce_str,
        'package': package,
        'signType': 'RSA',
        'paySign': pay_sign,
    }


def _create_wechat_payment(order, *, mode='native', openid='', client_ip=''):
    from wechatpayv3 import WeChatPayType

    client = _wechat_client()
    kwargs = {
        'description': '帷幄天下系列会议注册费',
        'out_trade_no': order.out_trade_no,
        'amount': {'total': order.outstanding_amount_fen},
    }
    if mode == 'jsapi':
        if not openid:
            raise PaymentConfigurationError('微信内支付缺少 openid。')
        kwargs['payer'] = {'openid': openid}
        kwargs['pay_type'] = WeChatPayType.JSAPI
    elif mode == 'h5':
        kwargs['scene_info'] = {
            'payer_client_ip': client_ip or '127.0.0.1',
            'h5_info': {'type': 'Wap'},
        }
        kwargs['pay_type'] = WeChatPayType.H5
    else:
        kwargs['pay_type'] = WeChatPayType.NATIVE

    try:
        code, message = client.pay(**kwargs)
    except Exception as exc:
        logger.exception(
            'WeChat payment request failed: order_id=%s out_trade_no=%s mode=%s openid_present=%s client_ip=%s',
            getattr(order, 'public_id', ''),
            getattr(order, 'out_trade_no', ''),
            mode,
            bool(openid),
            client_ip or '',
        )
        raise PaymentGatewayError('微信支付接口暂时不可用，请改用扫码支付。') from exc
    if code not in {200, 201}:
        logger.error(
            'WeChat payment gateway returned non-2xx: order_id=%s out_trade_no=%s mode=%s status=%s body=%s',
            getattr(order, 'public_id', ''),
            getattr(order, 'out_trade_no', ''),
            mode,
            code,
            message,
        )
        raise PaymentGatewayError('微信支付接口暂时不可用，请改用扫码支付。')
    payload = json.loads(message)
    if mode == 'jsapi':
        prepay_id = payload.get('prepay_id')
        if not prepay_id:
            raise PaymentGatewayError('微信支付未返回 prepay_id。')
        return {
            'channel': 'wechat_pay',
            'payment_mode': 'wechat_jsapi',
            'jsapi_params': _build_wechat_jsapi_params(prepay_id),
            'raw': payload,
        }
    if mode == 'h5':
        h5_url = payload.get('h5_url')
        if not h5_url:
            raise PaymentGatewayError('微信支付未返回 H5 支付地址。')
        return {
            'channel': 'wechat_pay',
            'payment_mode': 'wechat_h5',
            'h5_url': h5_url,
            'raw': payload,
        }

    qr_payload = payload.get('code_url')
    if not qr_payload:
        raise PaymentGatewayError('微信支付未返回二维码地址。')
    return {
        'channel': 'wechat_pay',
        'payment_mode': 'wechat_native',
        'qr_payload': qr_payload,
        'qr_image': _qr_data_url(qr_payload),
        'raw': payload,
    }


def _query_wechat_payment(order):
    client = _wechat_client()
    try:
        code, message = client.query(out_trade_no=order.out_trade_no)
    except Exception as exc:
        logger.exception(
            'WeChat payment query failed: order_id=%s out_trade_no=%s',
            getattr(order, 'public_id', ''),
            getattr(order, 'out_trade_no', ''),
        )
        raise PaymentGatewayError('微信支付查询暂时不可用，请稍后重试。') from exc
    if code != 200:
        logger.error(
            'WeChat payment query returned non-200: order_id=%s out_trade_no=%s status=%s body=%s',
            getattr(order, 'public_id', ''),
            getattr(order, 'out_trade_no', ''),
            code,
            message,
        )
        raise PaymentGatewayError('微信支付查询暂时不可用，请稍后重试。')
    payload = json.loads(message)
    trade_state = payload.get('trade_state')
    return {
        'paid': trade_state == 'SUCCESS',
        'trade_no': payload.get('transaction_id', ''),
        'status_text': trade_state or 'NOTPAY',
        'raw': payload,
    }
