from django.urls import path

from . import views

app_name = 'meetings'

urlpatterns = [
    path('conference/api/payment/create/', views.create_payment_session, name='payment_create'),
    path('conference/api/payment/check/', views.check_payment_status, name='payment_check'),
    path('conference/api/payment/resume-mobile/', views.resume_mobile_payment, name='payment_resume_mobile'),
    path('conference/api/payment/wechat-auth-callback/', views.wechat_oauth_callback, name='wechat_oauth_callback'),
    path('conference/api/submit/', views.submit_registration_order, name='registration_submit'),
    path('submit-manual-payment/', views.submit_manual_payment, name='submit_manual_payment'),
    path('conference/api/pre-register/', views.pre_register, name='pre_register'),
    path('conference/api/query/send-code/', views.send_query_code, name='query_send_code'),
    path('conference/api/query/verify/', views.verify_and_query, name='query_verify'),
    path('conference/api/query/bind-order/', views.bind_query_order, name='query_bind_order'),
    path('conference/api/apply-promo-code/', views.apply_promo_code, name='apply_promo_code'),
    path('conference/api/add-participant/', views.add_participant, name='add_participant'),
    path('conference/api/pre-pay/', views.pay_pre_registration, name='pre_pay'),
    path('conference/api/payment/alipay-notify/', views.alipay_notify, name='alipay_notify'),
    path('conference/api/payment/alipay-return/', views.alipay_return, name='alipay_return'),
    path('conference/api/payment/wechat-notify/', views.wechat_notify, name='wechat_notify'),
    # ── 收款 Webhook ──
    path('api/payment-webhook/', views.payment_webhook, name='payment_webhook'),
    path('api/payment-webhook/events/', views.payment_webhook_events_api, name='payment_webhook_events'),
    path('api/payment-webhook/mark/', views.payment_event_mark, name='payment_event_mark'),
    path('api/manual-webhook-confirm/', views.manual_webhook_confirm, name='manual_webhook_confirm'),
    # ── 收款确认管理界面 ──
    path('payment-dashboard/', views.payment_dashboard, name='payment_dashboard'),
]
