from decimal import Decimal

from django.db import migrations, models


def backfill_paid_amount(apps, schema_editor):
    MeetingRegistrationOrder = apps.get_model('meetings', 'MeetingRegistrationOrder')
    MeetingRegistrationOrder.objects.filter(
        payment_status='paid',
        paid_amount=Decimal('0.00'),
    ).update(paid_amount=models.F('total_amount'))


class Migration(migrations.Migration):

    dependencies = [
        ('meetings', '0015_refactor_registration'),
    ]

    operations = [
        migrations.AddField(
            model_name='meetingregistrationorder',
            name='paid_amount',
            field=models.DecimalField(decimal_places=2, default=Decimal('0.00'), max_digits=10),
        ),
        migrations.RunPython(backfill_paid_amount, migrations.RunPython.noop),
    ]
