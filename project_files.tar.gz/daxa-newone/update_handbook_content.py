#!/usr/bin/env python
"""
Script: update_handbook_content.py
Purpose: 更新 conference-handbook 页面的内容：
  1. 议程替换为 conference-registration 页面所展示的最新议程
  2. 签到地点从北京会议中心改为中国气象局
  3. 交通路线改为中国气象局（北京市海淀区中关村南大街46号）
  4. 午餐地点更新
  5. 位置标签更新

运行方式（在容器内）：
  docker exec daxaone_web python update_handbook_content.py
"""

import django
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "daxaone.settings.production")
django.setup()

from meetings.models import MeetingHandbookPage

handbook = MeetingHandbookPage.objects.filter(slug="conference-handbook").first()
if not handbook:
    print("ERROR: MeetingHandbookPage not found with slug=conference-handbook")
    exit(1)

print(f"Found page: {handbook.title} (id={handbook.id})")

# ─── 1. 签到时间与签到信息 ─────────────────────────────────────────────────────
# registration 页面显示签到时间 08:00-08:30
handbook.checkin_time = "签到时间：08:00—08:30"

handbook.checkin_details = (
    "<p><strong>签到地点</strong></p>"
    "<p>中国气象局 大厅签到台</p>"
    "<p>地址：北京市海淀区中关村南大街46号</p>"
    "<ul>"
    "<li>凭有效身份证件领取参会证</li>"
    "<li>餐券请在签到时领取</li>"
    "</ul>"
    "<p>注：进入中国气象局时，告知门卫参加当日研讨会即可放行。</p>"
)

# ─── 2. 上午议程（来自 registration 页面）──────────────────────────────────────
handbook.morning_agenda = (
    "<p><strong>会议主持</strong><br/>"
    "主办方领导</p>"
    "<table>"
    "<tr><td>08:30 - 08:50</td><td><strong>致辞、研讨会背景与目标介绍</strong><br/>主办方领导</td></tr>"
    "<tr><td>08:50 - 10:00</td><td><strong>主旨演讲一：&ldquo;十五五&rdquo;时期我国新能源发展的目标与任务</strong>"
    "<br/><em>60分钟演讲 + 10分钟问答</em><br/>能源领域权威专家</td></tr>"
    "<tr><td>10:00 - 10:10</td><td><strong>茶歇 &amp; 自由交流</strong></td></tr>"
    "<tr><td>10:10 - 11:20</td><td><strong>主旨演讲二：气候变化与极端天气事件对能源系统的风险与影响</strong>"
    "<br/><em>60分钟演讲 + 10分钟问答</em><br/>中国气象局专家</td></tr>"
    "<tr><td>11:20 - 12:30</td><td><strong>主旨演讲三：国外能源气象融合发展经验</strong>"
    "<br/><em>60分钟演讲 + 10分钟问答</em><br/>国际咨询机构专家</td></tr>"
    "</table>"
)

# ─── 3. 午餐（来自 registration 页面）─────────────────────────────────────────
handbook.lunch_details = (
    "<p>12:30 - 14:00　午餐及中国气象局参观</p>"
    "<p>就餐地点：中国气象局餐厅</p>"
    "<p>就餐时间：12:30 - 13:30</p>"
    "<p>会务组为参会嘉宾提供餐券，请在签到时领取。</p>"
)

# ─── 4. 下午议程（来自 registration 页面）──────────────────────────────────────
handbook.afternoon_agenda = (
    "<table>"
    "<tr><td>14:00 - 15:10</td><td><strong>主旨演讲四：中国能源气象服务体系建设现状与前景</strong>"
    "<br/><em>60分钟演讲 + 10分钟问答</em><br/>中国气象局专家</td></tr>"
    "<tr><td>15:10 - 16:20</td><td><strong>主旨演讲五：构建支撑新型电力系统的智慧能源气象服务体系</strong>"
    "<br/><em>60分钟演讲 + 10分钟问答</em><br/>智慧能源气象专家</td></tr>"
    "<tr><td>16:20 - 16:30</td><td><strong>茶歇 &amp; 自由交流</strong></td></tr>"
    "<tr><td>16:30 - 17:40</td><td><strong>主旨演讲六：推进能源气象服务体系建设相关政策问题</strong>"
    "<br/><em>60分钟演讲 + 10分钟问答</em><br/>能源领域权威专家</td></tr>"
    "<tr><td>17:40 - 18:00</td><td><strong>研讨会总结：关键观点总结与未来展望</strong><br/>主持人</td></tr>"
    "</table>"
)

# ─── 5. 交通路线：全部替换为中国气象局路线 ─────────────────────────────────────
handbook.transportation_details = (
    "<p>目的地：<strong>中国气象局</strong></p>"
    "<p>地址：<strong>北京市海淀区中关村南大街46号</strong></p>"
    "<ol>"
    "<li><strong>自驾车</strong><br/>"
    "可导航至中国气象局（北京市海淀区中关村南大街46号）。停车请遵守现场安保指引，"
    "告知门卫参加当日研讨会即可进入。</li>"
    "<li><strong>地铁</strong><br/>"
    "乘坐地铁4号线，在<strong>魏公村站</strong>下车（A口出），沿中关村南大街向南步行约800米，即可到达中国气象局正门。"
    "<br/>或乘坐地铁10号线，在<strong>苏州街站</strong>下车，换乘地铁4号线至魏公村站。</li>"
    "<li><strong>首都机场前往</strong><br/>"
    "乘坐机场快轨至三元桥站，换乘地铁10号线（巴沟方向）至苏州街站，换乘地铁4号线至魏公村站（A口出），步行约800米到达。"
    "<br/>或在三元桥站乘出租车/网约车前往中国气象局，约需30—40分钟。</li>"
    "<li><strong>大兴机场前往</strong><br/>"
    "乘坐大兴机场线至草桥站，换乘地铁10号线（巴沟方向）至苏州街站，换乘地铁4号线至魏公村站（A口出），步行约800米到达。"
    "<br/>或乘出租车/网约车直达，约需45—60分钟（视路况）。</li>"
    "<li><strong>北京西客站前往</strong><br/>"
    "乘坐地铁9号线至北京西站，换乘地铁4号线（安河桥北方向）至魏公村站（A口出），步行约800米到达。</li>"
    "<li><strong>北京站前往</strong><br/>"
    "乘坐地铁2号线至建国门站，换乘地铁1号线至木樨地站，或乘地铁10号线至苏州街站，换乘地铁4号线至魏公村站。</li>"
    "<li><strong>北京南站前往</strong><br/>"
    "乘坐地铁4号线（安河桥北方向），可直达魏公村站（A口出），步行约800米到达中国气象局。</li>"
    "<li><strong>打车/网约车（出示地址给司机）</strong><br/>"
    "目的地：中国气象局<br/>"
    "地址：北京市海淀区中关村南大街46号</li>"
    "</ol>"
)

# ─── 6. 位置标签（地图区域标题）─────────────────────────────────────────────────
handbook.location_label = "中国气象局（北京市海淀区中关村南大街46号）"

# ─── 7. 保存 ──────────────────────────────────────────────────────────────────
handbook.save_revision().publish()

print("✅ Done. MeetingHandbookPage updated and new revision published.")
print(f"   checkin_time:   {handbook.checkin_time}")
print(f"   location_label: {handbook.location_label}")
