import os
import django
from django.conf import settings

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'daxaone.settings')
django.setup()

from wagtail.images.models import Image

images = Image.objects.all()
print(f"Total Wagtail images: {images.count()}")
for img in images[:50]:
    print(f"ID: {img.id}, Title: {img.title}, File: {img.file.name}")
