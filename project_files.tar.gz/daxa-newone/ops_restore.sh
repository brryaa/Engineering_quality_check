#!/bin/bash
BACKUP_ROOT="/srv/backups"
PROJECT_DIR="/srv/daxa-newone"
cd "$BACKUP_ROOT" || exit 1
options=($(ls -d */ | sed 's/\///' | sort -r))
if [ ${#options[@]} -eq 0 ]; then echo "未发现备份"; exit 1; fi
PS3="请选择备份版本序号: "
select VERSION in "${options[@]}"; do
    if [ -n "$VERSION" ]; then
        BACKUP_PATH="$BACKUP_ROOT/$VERSION"
        read -p "确认恢复到 $VERSION 吗？(y/n): " CONF
        if [ "$CONF" != "y" ]; then exit 0; fi
        cd "$PROJECT_DIR" && docker-compose down
        sudo rm -rf "$PROJECT_DIR"
        sudo tar -xzf "$BACKUP_PATH/project_files.tar.gz" -C /srv
        sudo cp "$BACKUP_PATH/nginx.conf" /etc/nginx/sites-available/daxa-newone
        sudo nginx -t && sudo systemctl reload nginx
        cd "$PROJECT_DIR" && docker-compose up -d
        sleep 10
        cat "$BACKUP_PATH/db_dump.sql" | docker exec -i daxaone_db psql -U daxaone daxaone
        echo "恢复成功"
        break
    fi
done
