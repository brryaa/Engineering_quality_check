from wagtail.models import Site
from home.models import HomePage
from meetings.models import MeetingRegistrationPage

print("Updating Wagtail Sites...")
for site in Site.objects.all():
    print(f"Site ID {site.id} currently hostname={site.hostname}")
    if site.hostname == 'newone.daxa.ltd':
        site.hostname = 'ph3.711177.xyz'
        site.save()
        print(f"-> Updated site {site.id} to {site.hostname}")

print("\nUpdating HomePage URLs...")
for page in HomePage.objects.all():
    changed = False
    if page.primary_cta_url and 'newone.daxa.ltd' in page.primary_cta_url:
        page.primary_cta_url = page.primary_cta_url.replace('newone.daxa.ltd', 'ph3.711177.xyz')
        changed = True
    if page.secondary_cta_url and 'newone.daxa.ltd' in page.secondary_cta_url:
        page.secondary_cta_url = page.secondary_cta_url.replace('newone.daxa.ltd', 'ph3.711177.xyz')
        changed = True
    if changed:
        page.save()
        print(f"-> Updated HomePage {page.id}")

print("\nUpdating MeetingRegistrationPage URLs...")
for page in MeetingRegistrationPage.objects.all():
    changed = False
    if page.handbook_url and 'newone.daxa.ltd' in page.handbook_url:
        page.handbook_url = page.handbook_url.replace('newone.daxa.ltd', 'ph3.711177.xyz')
        changed = True
    if getattr(page, 'registration_url', None) and 'newone.daxa.ltd' in page.registration_url:
        page.registration_url = page.registration_url.replace('newone.daxa.ltd', 'ph3.711177.xyz')
        changed = True
    if getattr(page, 'home_url', None) and 'newone.daxa.ltd' in page.home_url:
        page.home_url = page.home_url.replace('newone.daxa.ltd', 'ph3.711177.xyz')
        changed = True
    if changed:
        page.save()
        print(f"-> Updated MeetingRegistrationPage {page.id}")

print("Done.")
