import re

with open('meetings/templates/meetings/meeting_registration_page.html', 'r', encoding='utf8') as f:
    html = f.read()

# Replace block 1
old_block_1 = """                                    <div class="form-inline-grid two-columns">
                                        <div class="form-row">
                                            <label>参会人姓名<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-full_name" type="text" placeholder="请输入姓名" required>
                                        </div>
                                        <div class="form-row">
                                            <label>参会人职务<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-job_title" type="text" placeholder="请输入职务" required>
                                        </div>
                                        <div class="form-row">
                                            <label>联系电话<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-phone_number" type="tel" pattern="^1[3-9]\d{9}$" title="请输入有效的11位手机号码" placeholder="请输入手机号" required>
                                        </div>
                                        <div class="form-row">
                                            <label>邮箱<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-email" type="email" pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" title="请输入有效的邮箱地址" placeholder="请填写收件邮箱" required>
                                        </div>
                                        <div class="form-row">
                                            <label>单位 / 公司<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-organization" type="text" placeholder="请输入单位全称" required>
                                        </div>
                                        <div class="form-row">
                                            <label>开票税号</label>
                                            <input class="meeting-input" name="attendees-0-invoice_tax_number" type="text" placeholder="如需开票请填写">
                                        </div>
                                    </div>
                                    <div class="invoice-radio-group">
                                        <p class="invoice-radio-label">开票抬头<span class="required-mark">*</span></p>
                                        <label class="invoice-radio-option">
                                            <input type="radio" name="attendees-0-invoice_title_choice" value="same_as_org" checked>
                                            <span>开票抬头同单位/公司名</span>
                                        </label>
                                        <label class="invoice-radio-option">
                                            <input type="radio" name="attendees-0-invoice_title_choice" value="see_notes">
                                            <span>开票抬头见备注</span>
                                        </label>
                                    </div>
                                    <div class="form-row">
                                        <label>备注</label>
                                        <textarea class="meeting-input meeting-textarea" name="attendees-0-notes" rows="2" placeholder="如需会务组协助或开票抬头另行说明，请在这里填写"></textarea>
                                    </div>"""

new_block_1 = """                                    <div class="form-inline-grid two-columns">
                                        <div class="form-row">
                                            <label>参会人姓名<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-full_name" type="text" placeholder="请输入姓名" required>
                                        </div>
                                        <div class="form-row">
                                            <label>联系电话<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-phone_number" type="tel" pattern="^1[3-9]\\d{9}$" title="请输入有效的11位手机号码" placeholder="请输入手机号" required>
                                        </div>
                                        <div class="form-row">
                                            <label>邮箱<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-email" type="email" pattern="^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$" title="请输入有效的邮箱地址" placeholder="请填写收件邮箱" required>
                                        </div>
                                        <div class="form-row">
                                            <label>单位 / 公司<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-organization" type="text" placeholder="请输入单位全称" required>
                                        </div>
                                        <div class="form-row">
                                            <label>参会人职务<span class="required-mark">*</span></label>
                                            <input class="meeting-input" name="attendees-0-job_title" type="text" placeholder="请输入职务" required>
                                        </div>
                                        <div class="form-row">
                                            <label>部门</label>
                                            <input class="meeting-input" name="attendees-0-department" type="text" placeholder="若有请填写">
                                        </div>
                                    </div>
                                    <div class="invoice-radio-group">
                                        <p class="invoice-radio-label">开票抬头<span class="required-mark">*</span></p>
                                        <label class="invoice-radio-option">
                                            <input type="radio" name="attendees-0-invoice_title_choice" value="same_as_org" checked>
                                            <span>开票抬头同单位/公司名</span>
                                        </label>
                                        <label class="invoice-radio-option">
                                            <input type="radio" name="attendees-0-invoice_title_choice" value="see_notes">
                                            <span>开票抬头见备注</span>
                                        </label>
                                    </div>
                                    <div class="form-row" style="margin-top: 6px;">
                                        <label>开票税号</label>
                                        <input class="meeting-input" name="attendees-0-invoice_tax_number" type="text" placeholder="如需开票请填写税号">
                                    </div>
                                    <div class="form-row" style="margin-top: 14px;">
                                        <label>备注</label>
                                        <textarea class="meeting-input meeting-textarea" name="attendees-0-notes" rows="2" placeholder="如需会务组协助或开票抬头另行说明，请在这里填写"></textarea>
                                    </div>"""


# Replace block 2
old_block_2 = """                        <div class="form-inline-grid two-columns">
                            <div class="form-row">
                                <label>参会人姓名<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-full_name" type="text" placeholder="请输入姓名" required>
                            </div>
                            <div class="form-row">
                                <label>参会人职务<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-job_title" type="text" placeholder="请输入职务" required>
                            </div>
                            <div class="form-row">
                                <label>联系电话<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-phone_number" type="tel" pattern="^1[3-9]\d{9}$" title="请输入有效的11位手机号码" placeholder="请输入手机号" required>
                            </div>
                            <div class="form-row">
                                <label>邮箱<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-email" type="email" pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" title="请输入有效的邮箱地址" placeholder="请填写收件邮箱" required>
                            </div>
                            <div class="form-row">
                                <label>单位 / 公司<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-organization" type="text" placeholder="请输入单位全称" required>
                            </div>
                            <div class="form-row">
                                <label>开票税号</label>
                                <input class="meeting-input" name="attendees-__index__-invoice_tax_number" type="text" placeholder="如需开票请填写">
                            </div>
                        </div>
                        <div class="invoice-radio-group">
                            <p class="invoice-radio-label">开票抬头<span class="required-mark">*</span></p>
                            <label class="invoice-radio-option">
                                <input type="radio" name="attendees-__index__-invoice_title_choice" value="same_as_org" checked>
                                <span>开票抬头同单位/公司名</span>
                            </label>
                            <label class="invoice-radio-option">
                                <input type="radio" name="attendees-__index__-invoice_title_choice" value="see_notes">
                                <span>开票抬头见备注</span>
                            </label>
                        </div>
                        <div class="form-row">
                            <label>备注</label>
                            <textarea class="meeting-input meeting-textarea" name="attendees-__index__-notes" rows="2" placeholder="如需会务组协助或开票抬头另行说明，请在这里填写"></textarea>
                        </div>"""

new_block_2 = """                        <div class="form-inline-grid two-columns">
                            <div class="form-row">
                                <label>参会人姓名<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-full_name" type="text" placeholder="请输入姓名" required>
                            </div>
                            <div class="form-row">
                                <label>联系电话<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-phone_number" type="tel" pattern="^1[3-9]\\d{9}$" title="请输入有效的11位手机号码" placeholder="请输入手机号" required>
                            </div>
                            <div class="form-row">
                                <label>邮箱<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-email" type="email" pattern="^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$" title="请输入有效的邮箱地址" placeholder="请填写收件邮箱" required>
                            </div>
                            <div class="form-row">
                                <label>单位 / 公司<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-organization" type="text" placeholder="请输入单位全称" required>
                            </div>
                            <div class="form-row">
                                <label>参会人职务<span class="required-mark">*</span></label>
                                <input class="meeting-input" name="attendees-__index__-job_title" type="text" placeholder="请输入职务" required>
                            </div>
                            <div class="form-row">
                                <label>部门</label>
                                <input class="meeting-input" name="attendees-__index__-department" type="text" placeholder="若有请填写">
                            </div>
                        </div>
                        <div class="invoice-radio-group">
                            <p class="invoice-radio-label">开票抬头<span class="required-mark">*</span></p>
                            <label class="invoice-radio-option">
                                <input type="radio" name="attendees-__index__-invoice_title_choice" value="same_as_org" checked>
                                <span>开票抬头同单位/公司名</span>
                            </label>
                            <label class="invoice-radio-option">
                                <input type="radio" name="attendees-__index__-invoice_title_choice" value="see_notes">
                                <span>开票抬头见备注</span>
                            </label>
                        </div>
                        <div class="form-row" style="margin-top: 6px;">
                            <label>开票税号</label>
                            <input class="meeting-input" name="attendees-__index__-invoice_tax_number" type="text" placeholder="如需开票请填写税号">
                        </div>
                        <div class="form-row" style="margin-top: 14px;">
                            <label>备注</label>
                            <textarea class="meeting-input meeting-textarea" name="attendees-__index__-notes" rows="2" placeholder="如需会务组协助或开票抬头另行说明，请在这里填写"></textarea>
                        </div>"""

if old_block_1 in html:
    html = html.replace(old_block_1, new_block_1)
    print("Replaced block 1")
else:
    print("Block 1 not found!")

if old_block_2 in html:
    html = html.replace(old_block_2, new_block_2)
    print("Replaced block 2")
else:
    print("Block 2 not found!")

old_consent = """                    <div class="form-row form-row-consent">
                        <label class="consent-row" for="consent-acknowledged">
                            <input id="consent-acknowledged" class="meeting-checkbox" name="consent_acknowledged" type="checkbox" value="on" required>
                            <span>我同意参会须知并确认所填信息真实有效</span>
                        </label>
                        <p class="consent-copy">{{ page.consent_copy }}</p>
                    </div>

                    <div class="meeting-form-feedback" data-form-feedback hidden></div>"""

# Remove old consent row and empty line. Wait, we'll just extract it and place it before step 2.

html = html.replace(old_consent, """                    <div class="meeting-form-feedback" data-form-feedback hidden></div>""")

# Now find where to insert consent. Step 2 starts with "<section class="meeting-step-card">"
insert_target = """                    <section class="meeting-step-card">
                        <div class="section-heading compact-heading">
                            <p class="eyebrow">步骤 2</p>"""

new_insert = """                    <div class="form-row form-row-consent" style="margin-top:20px; margin-bottom: 0px;">
                        <label class="consent-row" for="consent-acknowledged">
                            <input id="consent-acknowledged" class="meeting-checkbox" name="consent_acknowledged" type="checkbox" value="on" required>
                            <span>我同意参会须知并确认所填信息真实有效</span>
                        </label>
                        <p class="consent-copy">{{ page.consent_copy }}</p>
                    </div>

                    <section class="meeting-step-card" style="padding-top: 0;">
                        <div class="section-heading compact-heading">
                            <p class="eyebrow">步骤 2</p>"""

html = html.replace(insert_target, new_insert)
print("Replaced consent block.")

with open('meetings/templates/meetings/meeting_registration_page.html', 'w', encoding='utf8') as f:
    f.write(html)
