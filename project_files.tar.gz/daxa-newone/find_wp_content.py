import os
import django
from django.apps import apps
from django.db.models import CharField, TextField, JSONField

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'daxaone.settings')
django.setup()

def find_wp_content():
    search_string = 'wp-content'
    found = False
    for model in apps.get_models():
        fields = [f.name for f in model._meta.fields if isinstance(f, (CharField, TextField, JSONField))]
        if not fields:
            continue
        try:
            for obj in model.objects.all():
                for f in fields:
                    val = getattr(obj, f)
                    if val and search_string in str(val):
                        print(f"Found in {model.__name__} (ID: {obj.pk}) field: {f}")
                        print(f"Content snippet: {str(val)[:100]}...")
                        found = True
        except Exception as e:
            # print(f"Error searching {model.__name__}: {e}")
            pass
    if not found:
        print("No 'wp-content' found in the database.")

if __name__ == "__main__":
    find_wp_content()
