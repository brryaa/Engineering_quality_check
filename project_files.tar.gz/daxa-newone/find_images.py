import re
from wagtail.models import Page
for p in Page.objects.all():
    page = p.specific
    fields = [f.name for f in page._meta.fields if f.get_internal_type() in ['TextField', 'JSONField']]
    for f in fields:
        val = getattr(page, f)
        if val:
            content = str(val)
            imgs = re.findall(r'<img[^>]*>', content)
            embeds = re.findall(r'<embed[^>]*>', content)
            if imgs or embeds:
                print(f"Page ID {page.id} type {page.__class__.__name__} field {f} has images:")
                for i in imgs: print("  IMG:", i)
                for e in embeds: print("  EMBED:", e)
