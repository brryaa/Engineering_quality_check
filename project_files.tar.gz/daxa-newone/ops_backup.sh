#!/bin/bash
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_ROOT="/srv/backups"
BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"
PROJECT_DIR="/srv/daxa-newone"
NGINX_CONF="/etc/nginx/sites-available/daxa-newone"
sudo mkdir -p "$BACKUP_DIR"
docker exec daxaone_db pg_dump -U daxaone daxaone > /tmp/db_dump.sql
sudo mv /tmp/db_dump.sql "$BACKUP_DIR/db_dump.sql"
sudo cp "$NGINX_CONF" "$BACKUP_DIR/nginx.conf"
sudo tar -czf "$BACKUP_DIR/project_files.tar.gz" --exclude='./.git' -C /srv daxa-newone
cd "$BACKUP_ROOT" && ls -dt */ | tail -n +4 | xargs -r sudo rm -rf
