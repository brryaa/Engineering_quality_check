from wagtail.models import Page
for p in Page.objects.all():
    page = p.specific
    fields = [f.name for f in page._meta.fields if f.get_internal_type() in ['TextField', 'JSONField']]
    for f in fields:
        val = getattr(page, f)
        if val and 'newone.daxa.ltd' in str(val):
            print(f"Found in {page.__class__.__name__} {page.id} field {f}")
