from django.conf import settings
from django.urls import include, path, re_path
from django.contrib import admin
from django.contrib.sitemaps.views import sitemap
from django.views.generic import RedirectView
from django.views.static import serve as static_serve

from wagtail.admin import urls as wagtailadmin_urls
from wagtail.contrib.sitemaps import Sitemap
from wagtail import urls as wagtail_urls
from wagtail.documents import urls as wagtaildocs_urls

from search import views as search_views
from meetings.views import input_test

urlpatterns = [
    path('inputtest.html', input_test, name='input_test'),
    path('django-admin/meetings/meetingregistration/', RedirectView.as_view(url='/django-admin/meetings/meetingregistrationorder/', permanent=True)),
    path('django-admin/', admin.site.urls),
    path('admin/', include(wagtailadmin_urls)),
    path('documents/', include(wagtaildocs_urls)),
    path('search/', search_views.search, name='search'),
    path('sitemap.xml', sitemap, {'sitemaps': {'wagtail': Sitemap}}),
    re_path(r'^media/(?P<path>.*)$', static_serve, {'document_root': settings.MEDIA_ROOT}),
    path('conference-registration/', RedirectView.as_view(url='/conference/', permanent=True)),
    path('', include('meetings.urls')),
    path('', include(wagtail_urls)),
]
