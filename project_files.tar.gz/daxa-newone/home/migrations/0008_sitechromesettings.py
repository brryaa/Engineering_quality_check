import django.db.models.deletion
from django.db import migrations, models


def create_default_site_chrome_settings(apps, schema_editor):
    Site = apps.get_model("wagtailcore.Site")
    SiteChromeSettings = apps.get_model("home.SiteChromeSettings")

    default_site = Site.objects.filter(is_default_site=True).first()
    if default_site:
        SiteChromeSettings.objects.get_or_create(site=default_site)


def remove_default_site_chrome_settings(apps, schema_editor):
    Site = apps.get_model("wagtailcore.Site")
    SiteChromeSettings = apps.get_model("home.SiteChromeSettings")

    default_site = Site.objects.filter(is_default_site=True).first()
    if default_site:
        SiteChromeSettings.objects.filter(site=default_site).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("home", "0007_alter_homepage_hero_intro_alter_homepage_hero_kicker"),
        ("wagtailcore", "0096_referenceindex_referenceindex_source_object_and_more"),
    ]

    operations = [
        migrations.CreateModel(
            name="SiteChromeSettings",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("brand_name", models.CharField(default="大下科技", max_length=80)),
                ("brand_subtitle", models.CharField(default="服务天下", max_length=80)),
                ("nav_home_label", models.CharField(default="首页", max_length=20)),
                ("nav_home_url", models.CharField(default="/", max_length=255)),
                ("nav_registration_label", models.CharField(default="会议报名", max_length=20)),
                (
                    "nav_registration_url",
                    models.CharField(default="/conference-registration/", max_length=255),
                ),
                ("nav_articles_label", models.CharField(default="文章", max_length=20)),
                ("nav_articles_url", models.CharField(default="/articles/", max_length=255)),
                ("nav_workspace_label", models.CharField(default="频道", max_length=20)),
                ("nav_workspace_url", models.CharField(default="/workspace/", max_length=255)),
                ("banner_kicker", models.CharField(default="DAXA", max_length=40)),
                ("banner_title", models.CharField(default="服务天下", max_length=80)),
                ("footer_title", models.CharField(default="大下科技", max_length=80)),
                ("footer_copy", models.CharField(default="服务天下", max_length=80)),
                (
                    "footer_meta",
                    models.TextField(
                        default="聚焦研究内容、数据服务、国际会议与专题合作。围绕议题组织内容，围绕协作建设频道。"
                    ),
                ),
                (
                    "site",
                    models.OneToOneField(
                        editable=False,
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="home_site_chrome_settings",
                        to="wagtailcore.site",
                    ),
                ),
            ],
            options={
                "abstract": False,
            },
        ),
        migrations.RunPython(
            create_default_site_chrome_settings,
            remove_default_site_chrome_settings,
        ),
    ]
