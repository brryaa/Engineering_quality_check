from django.db import migrations


def seed_site_chrome_streamfields(apps, schema_editor):
    SiteChromeSettings = apps.get_model("home", "SiteChromeSettings")

    for settings in SiteChromeSettings.objects.all():
        updates = []
        if not settings.nav_items:
            settings.nav_items = [
                {"type": "item", "value": {"label": "首页", "relative_url": "/", "url": "", "open_in_new_tab": False}},
                {"type": "item", "value": {"label": "会议报名", "relative_url": "/conference-registration/", "url": "", "open_in_new_tab": False}},
                {"type": "item", "value": {"label": "文章", "relative_url": "/articles/", "url": "", "open_in_new_tab": False}},
                {"type": "item", "value": {"label": "频道", "relative_url": "/workspace/", "url": "", "open_in_new_tab": False}},
            ]
            updates.append("nav_items")
        if not settings.direction_cards:
            settings.direction_cards = [
                {"type": "item", "value": {"eyebrow": "Insight", "title": "前沿洞察", "relative_url": "/articles/", "url": "", "summary": "围绕重点议题发布观察文章、专题解读与公开观点，形成持续更新的内容输出。"}},
                {"type": "item", "value": {"eyebrow": "Data", "title": "数据与调研", "relative_url": "/workspace/data-analytics/", "url": "", "summary": "将数据服务、研究支持与专题分析组织为一组清晰的业务页面，便于介绍与协作。"}},
                {"type": "item", "value": {"eyebrow": "Thinktank", "title": "大下智库", "relative_url": "/thinktank/", "url": "", "summary": "集中呈现研究方向、智库内容与合作主题，形成品牌表达与议题组织的核心入口。"}},
                {"type": "item", "value": {"eyebrow": "Events", "title": "活动报名", "relative_url": "/conference-registration/", "url": "", "summary": "聚合国际会议、高端论坛与报名流程，让活动组织与内容传播保持同一节奏。"}},
            ]
            updates.append("direction_cards")
        if not settings.about_cards:
            settings.about_cards = [
                {"type": "item", "value": {"eyebrow": "关于大下科技", "title": "大下科技（北京）有限公司成立于 2022 年", "body": "聚焦能源、汽车、跨文化交流与国际合作等主题，通过研究、数据、活动与专题服务支持产业交流与判断。"}},
                {"type": "item", "value": {"eyebrow": "服务结构", "title": "技术服务与商业咨询", "body": "围绕能源、汽车、国际关系与跨文化研究等方向提供研究、咨询、活动与能力建设支持。"}},
                {"type": "item", "value": {"eyebrow": "工作方式", "title": "以议题组织内容，以页面承接业务", "body": "每个频道都围绕真实主题和实际协作场景展开，让文章、页面、活动与数据服务彼此联动。"}},
            ]
            updates.append("about_cards")
        if not settings.footer_links:
            settings.footer_links = [
                {"type": "item", "value": {"label": "首页", "relative_url": "/", "url": ""}},
                {"type": "item", "value": {"label": "文章", "relative_url": "/articles/", "url": ""}},
                {"type": "item", "value": {"label": "会议报名", "relative_url": "/conference-registration/", "url": ""}},
            ]
            updates.append("footer_links")
        if updates:
            settings.save(update_fields=updates)


class Migration(migrations.Migration):

    dependencies = [
        ("home", "0009_sitechromesettings_about_cards_and_more"),
    ]

    operations = [
        migrations.RunPython(seed_site_chrome_streamfields, migrations.RunPython.noop),
    ]
