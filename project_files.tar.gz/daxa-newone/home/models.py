from django.db import models

from modelcluster.fields import ParentalKey
from wagtail import blocks
from wagtail.admin.panels import FieldPanel, InlinePanel, MultiFieldPanel
from wagtail.contrib.settings.models import BaseSiteSetting, register_setting
from wagtail.fields import RichTextField, StreamField
from wagtail.models import Orderable, Page


HOME_CHANNEL_CARD_COPY = {
    "thinktank": {
        "eyebrow": "Research",
        "summary": "围绕重点议题、研究输出与合作主题组织内容，形成面向公众与合作伙伴的研究入口。",
    },
    "articles": {
        "eyebrow": "Library",
        "summary": "集中呈现观察文章、资讯发布和专题内容，保持清晰的时间线与议题分类。",
    },
    "contact-us": {
        "eyebrow": "Contact",
        "summary": "提供搜索、会务与业务入口的统一联系页，便于快速进入合适的协作场景。",
    },
}


class NavItemBlock(blocks.StructBlock):
    label = blocks.CharBlock(required=True, max_length=40)
    url = blocks.URLBlock(required=False)
    relative_url = blocks.CharBlock(required=False, max_length=255, help_text="可填 /articles/ 这类站内路径")
    open_in_new_tab = blocks.BooleanBlock(required=False, default=False)


class LinkCardBlock(blocks.StructBlock):
    eyebrow = blocks.CharBlock(required=True, max_length=40)
    title = blocks.CharBlock(required=True, max_length=80)
    url = blocks.URLBlock(required=False)
    relative_url = blocks.CharBlock(required=False, max_length=255, help_text="可填 /workspace/ 这类站内路径")
    summary = blocks.TextBlock(required=True)


class AboutCardBlock(blocks.StructBlock):
    eyebrow = blocks.CharBlock(required=False, max_length=40)
    title = blocks.CharBlock(required=True, max_length=120)
    body = blocks.TextBlock(required=True)


class FooterLinkBlock(blocks.StructBlock):
    label = blocks.CharBlock(required=True, max_length=40)
    url = blocks.URLBlock(required=False)
    relative_url = blocks.CharBlock(required=False, max_length=255, help_text="可填 /conference/ 这类站内路径")


@register_setting
class SiteChromeSettings(BaseSiteSetting):
    brand_name = models.CharField(max_length=80, default="大下科技")
    brand_subtitle = models.CharField(max_length=80, default="服务天下")

    nav_home_label = models.CharField(max_length=20, default="首页")
    nav_home_url = models.CharField(max_length=255, default="/")
    nav_registration_label = models.CharField(max_length=20, default="会议报名")
    nav_registration_url = models.CharField(max_length=255, default="/conference/")
    nav_articles_label = models.CharField(max_length=20, default="文章")
    nav_articles_url = models.CharField(max_length=255, default="/articles/")
    nav_workspace_label = models.CharField(max_length=20, default="频道")
    nav_workspace_url = models.CharField(max_length=255, default="/workspace/")
    nav_items = StreamField([("item", NavItemBlock())], blank=True, default=list, use_json_field=True)

    banner_kicker = models.CharField(max_length=40, default="DAXA")
    banner_title = models.CharField(max_length=80, default="服务天下")

    hero_panel_label = models.CharField(max_length=60, default="DAXA Platform")
    hero_panel_title = models.CharField(max_length=160, default="研究内容、数据服务与高端活动在同一平台协同展开")
    hero_panel_body = RichTextField(
        blank=True,
        features=["bold", "italic", "link"],
        default=(
            "<p>站点内容围绕研究频道、数据能力、活动组织和专题服务展开，让文章、页面与业务入口在同一内容体系中协同更新。</p>"
        ),
    )

    direction_section_eyebrow = models.CharField(max_length=60, default="Core Channels")
    direction_section_title = models.CharField(max_length=160, default="四个核心入口构成品牌、内容与服务的公开界面")
    direction_cards = StreamField([("item", LinkCardBlock())], blank=True, default=list, use_json_field=True)

    about_section_eyebrow = models.CharField(max_length=60, default="About")
    about_section_title = models.CharField(max_length=160, default="首页中的品牌介绍与服务说明由后台统一维护")
    about_cards = StreamField([("item", AboutCardBlock())], blank=True, default=list, use_json_field=True)

    channels_section_eyebrow = models.CharField(max_length=60, default="Main Channels")
    channels_section_title = models.CharField(max_length=160, default="以少量清晰频道承接公开内容、合作入口与品牌表达")

    workspace_section_eyebrow = models.CharField(max_length=60, default="Workspace")
    workspace_section_title = models.CharField(max_length=160, default="围绕研究、服务、数据与活动建立专题频道体系")
    workspace_hub_label = models.CharField(max_length=60, default="频道总览")
    workspace_hub_button_label = models.CharField(max_length=40, default="浏览频道")
    workspace_card_eyebrow = models.CharField(max_length=40, default="Channel")

    event_section_eyebrow = models.CharField(max_length=60, default="Event Access")
    event_section_title = models.CharField(max_length=160, default="以活动报名、会务信息与议题内容形成完整的活动入口")
    event_section_body = models.TextField(
        default="会议与论坛页面既服务于报名，也承接议题说明、参会信息与内容传播。"
    )
    event_primary_label = models.CharField(max_length=40, default="立即报名")
    event_primary_url = models.CharField(max_length=255, default="/conference/")
    event_secondary_label = models.CharField(max_length=40, default="活动频道")
    event_secondary_url = models.CharField(max_length=255, default="/workspace/events/")

    insights_section_eyebrow = models.CharField(max_length=60, default="Latest Insights")
    insights_section_title = models.CharField(max_length=160, default="持续更新的文章、观察与专题内容")
    insights_button_label = models.CharField(max_length=40, default="查看全部文章")

    topic_matrix_section_eyebrow = models.CharField(max_length=60, default="Topic Matrix")
    topic_matrix_section_title = models.CharField(max_length=160, default="围绕重点主题形成清晰的能力与内容板块")

    approach_section_eyebrow = models.CharField(max_length=60, default="Approach")
    approach_section_title = models.CharField(max_length=160, default="围绕内容、协作与活动形成统一的工作方式")

    footer_title = models.CharField(max_length=80, default="大下科技")
    footer_copy = models.CharField(max_length=80, default="服务天下")
    footer_meta = models.TextField(
        default="聚焦研究内容、数据服务、国际会议与专题合作。围绕议题组织内容，围绕协作建设频道。"
    )
    footer_links = StreamField([("item", FooterLinkBlock())], blank=True, default=list, use_json_field=True)

    panels = [
        MultiFieldPanel([FieldPanel("brand_name"), FieldPanel("brand_subtitle")], heading="品牌"),
        MultiFieldPanel(
            [
                FieldPanel("nav_home_label"),
                FieldPanel("nav_home_url"),
                FieldPanel("nav_registration_label"),
                FieldPanel("nav_registration_url"),
                FieldPanel("nav_articles_label"),
                FieldPanel("nav_articles_url"),
                FieldPanel("nav_workspace_label"),
                FieldPanel("nav_workspace_url"),
                FieldPanel("nav_items"),
            ],
            heading="顶部导航",
        ),
        MultiFieldPanel([FieldPanel("banner_kicker"), FieldPanel("banner_title")], heading="顶部横幅"),
        MultiFieldPanel(
            [FieldPanel("hero_panel_label"), FieldPanel("hero_panel_title"), FieldPanel("hero_panel_body")],
            heading="首页 Hero 侧卡",
        ),
        MultiFieldPanel(
            [FieldPanel("direction_section_eyebrow"), FieldPanel("direction_section_title"), FieldPanel("direction_cards")],
            heading="首页入口卡片",
        ),
        MultiFieldPanel(
            [FieldPanel("about_section_eyebrow"), FieldPanel("about_section_title"), FieldPanel("about_cards")],
            heading="关于区",
        ),
        MultiFieldPanel([FieldPanel("channels_section_eyebrow"), FieldPanel("channels_section_title")], heading="主频道区"),
        MultiFieldPanel(
            [
                FieldPanel("workspace_section_eyebrow"),
                FieldPanel("workspace_section_title"),
                FieldPanel("workspace_hub_label"),
                FieldPanel("workspace_hub_button_label"),
                FieldPanel("workspace_card_eyebrow"),
            ],
            heading="频道总览区",
        ),
        MultiFieldPanel(
            [
                FieldPanel("event_section_eyebrow"),
                FieldPanel("event_section_title"),
                FieldPanel("event_section_body"),
                FieldPanel("event_primary_label"),
                FieldPanel("event_primary_url"),
                FieldPanel("event_secondary_label"),
                FieldPanel("event_secondary_url"),
            ],
            heading="活动入口区",
        ),
        MultiFieldPanel(
            [FieldPanel("insights_section_eyebrow"), FieldPanel("insights_section_title"), FieldPanel("insights_button_label")],
            heading="文章区",
        ),
        MultiFieldPanel([FieldPanel("topic_matrix_section_eyebrow"), FieldPanel("topic_matrix_section_title")], heading="专题矩阵区"),
        MultiFieldPanel([FieldPanel("approach_section_eyebrow"), FieldPanel("approach_section_title")], heading="工作方式区"),
        MultiFieldPanel(
            [FieldPanel("footer_title"), FieldPanel("footer_copy"), FieldPanel("footer_meta"), FieldPanel("footer_links")],
            heading="页脚",
        ),
    ]


class HomePage(Page):
    max_count = 1
    parent_page_types = ["wagtailcore.Page"]
    subpage_types = [
        "sitecontent.StandardPage",
        "sitecontent.ArticleIndexPage",
        "meetings.MeetingRegistrationPage",
        "meetings.MeetingHandbookPage",
    ]

    hero_kicker = models.CharField(max_length=80, default="服务天下")
    hero_title = models.CharField(max_length=160, default="研究、数据、活动与能力建设，在同一平台协同呈现。")
    hero_intro = RichTextField(
        features=["bold", "italic", "link"],
        default=(
            "<p>大下科技围绕能源与气候、汽车与交通、国际合作等主题，持续提供研究内容、数据支持、活动组织与专题服务。</p>"
        ),
    )
    primary_cta_label = models.CharField(max_length=40, default="会议报名")
    primary_cta_url = models.URLField(blank=True, default="https://daxa.ltd/conference/")
    secondary_cta_label = models.CharField(max_length=40, default="查看频道")
    secondary_cta_url = models.URLField(blank=True, default="https://daxa.ltd/workspace/")
    status_note = models.CharField(max_length=120, default="聚焦研究判断、数据服务、国际会议与专题合作。")
    migration_summary = RichTextField(
        blank=True,
        features=["bold", "italic", "link"],
        default=(
            "<p>站点内容围绕研究频道、数据能力、活动组织和专题服务展开，让文章、页面与业务入口在同一内容体系中协同更新。</p>"
        ),
    )

    content_panels = Page.content_panels + [
        MultiFieldPanel(
            [
                FieldPanel("hero_kicker"),
                FieldPanel("hero_title"),
                FieldPanel("hero_intro"),
                FieldPanel("primary_cta_label"),
                FieldPanel("primary_cta_url"),
                FieldPanel("secondary_cta_label"),
                FieldPanel("secondary_cta_url"),
                FieldPanel("status_note"),
                FieldPanel("migration_summary"),
            ],
            heading="Hero",
        ),
        InlinePanel("highlights", label="关键指标"),
        InlinePanel("capabilities", label="核心能力"),
        InlinePanel("migration_phases", label="迁移阶段"),
    ]

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)

        from sitecontent.models import ArticleIndexPage, ArticlePage
        from workspace.models import WorkspaceModule

        workspace_hub = Page.objects.live().descendant_of(self).filter(slug="workspace").first()
        channel_pages = [
            page.specific
            for slug in ["thinktank", "articles", "contact-us"]
            for page in Page.objects.live().descendant_of(self).filter(slug=slug)[:1]
        ]
        context["channel_pages"] = channel_pages
        context["channel_cards"] = [
            {
                "page": item,
                "eyebrow": HOME_CHANNEL_CARD_COPY.get(item.slug, {}).get("eyebrow", "Channel"),
                "summary": HOME_CHANNEL_CARD_COPY.get(item.slug, {}).get(
                    "summary",
                    item.intro or "这一页汇总了对应主题的核心内容与业务入口。",
                ),
            }
            for item in channel_pages
        ]
        if workspace_hub:
            context["workspace_channel_pages"] = [
                page.specific
                for page in Page.objects.live().child_of(workspace_hub).order_by("path")
            ]
        else:
            context["workspace_channel_pages"] = []
        context["workspace_hub"] = workspace_hub
        context["article_index"] = ArticleIndexPage.objects.live().filter(slug="articles").first()
        context["latest_articles"] = ArticlePage.objects.live().order_by("-date", "-first_published_at")[:3]
        context["workspace_modules"] = WorkspaceModule.objects.order_by("title")[:6]
        return context


class HomeHighlight(Orderable):
    page = ParentalKey(HomePage, related_name="highlights", on_delete=models.CASCADE)
    label = models.CharField(max_length=60)
    value = models.CharField(max_length=60)
    note = models.CharField(max_length=100, blank=True)

    panels = [FieldPanel("label"), FieldPanel("value"), FieldPanel("note")]


class HomeCapability(Orderable):
    page = ParentalKey(HomePage, related_name="capabilities", on_delete=models.CASCADE)
    eyebrow = models.CharField(max_length=40)
    title = models.CharField(max_length=80)
    description = models.TextField()

    panels = [FieldPanel("eyebrow"), FieldPanel("title"), FieldPanel("description")]


class HomeMigrationPhase(Orderable):
    page = ParentalKey(HomePage, related_name="migration_phases", on_delete=models.CASCADE)
    phase = models.CharField(max_length=40)
    title = models.CharField(max_length=100)
    description = models.TextField()

    panels = [FieldPanel("phase"), FieldPanel("title"), FieldPanel("description")]
