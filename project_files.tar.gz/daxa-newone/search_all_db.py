import django
from django.apps import apps
from django.db.models import CharField, TextField, JSONField

def find_string_in_db(search_string):
    for model in apps.get_models():
        fields = [f.name for f in model._meta.fields if isinstance(f, (CharField, TextField, JSONField))]
        if not fields:
            continue
        try:
            for obj in model.objects.all():
                for f in fields:
                    val = getattr(obj, f)
                    if val and search_string in str(val):
                        print(f"Found in {model.__name__} ID {obj.pk} field {f}")
        except Exception as e:
            pass

find_string_in_db('newone.daxa.ltd')
