# 会议系统极简故障切换手册

## 正常入口
- 报名页：`https://newone.daxa.ltd/conference-registration/`
- 管理后台：`https://newone.daxa.ltd/django-admin/meetings/meetingregistration/`
- 备用入口：`https://newone.daxa.ltd/backup-registration/`

## 日常备份
- 数据库：每小时拉取到宿主机
- `media`：每 4 小时拉取到宿主机
- 宿主机备份目录：`/home/brrr/codex/host-backups/newone/`

## 故障判断
- 首页打不开或报名页返回 `5xx`
- 后台无法打开
- 提交报名后持续报错

## 第一响应
1. 先打开备用报名页，确认静态备用入口仍可访问。
2. 在会务群或通知渠道发布备用报名链接：`https://newone.daxa.ltd/backup-registration/`
3. 提醒参会人按备用页模板发送报名信息与附件。

## 数据恢复
1. 数据库最新备份：`/home/brrr/codex/host-backups/newone/db/latest.sql.gz`
2. 媒体最新备份：`/home/brrr/codex/host-backups/newone/media/latest.tar.gz`

## 恢复后核查
1. 打开首页与报名页，确认返回 `200`
2. 提交一条测试报名
3. 后台确认能看到记录
4. 删除测试记录
