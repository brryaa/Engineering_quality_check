#!/usr/bin/env bash
set -euo pipefail

REMOTE_HOST="ubuntu@ph3.711177.xyz"
REMOTE_APP_DIR="/srv/daxa-newone"
BASE_URL="https://newone.daxa.ltd"

python3 - <<'PY'
import re
from io import BytesIO

import requests

BASE_URL = "https://newone.daxa.ltd"


def bmp_bytes(width, height):
    row = width * 3
    padding = (4 - row % 4) % 4
    row_padded = row + padding
    image_size = row_padded * height
    file_size = 54 + image_size
    header = bytearray()
    header += b"BM"
    header += file_size.to_bytes(4, "little")
    header += (0).to_bytes(4, "little")
    header += (54).to_bytes(4, "little")
    header += (40).to_bytes(4, "little")
    header += width.to_bytes(4, "little")
    header += height.to_bytes(4, "little")
    header += (1).to_bytes(2, "little")
    header += (24).to_bytes(2, "little")
    header += (0).to_bytes(4, "little")
    header += image_size.to_bytes(4, "little")
    header += (2835).to_bytes(4, "little") * 2
    header += (0).to_bytes(4, "little") * 2
    pixel = (b"\x44\x44\xCC" * width) + (b"\x00" * padding)
    return bytes(header) + pixel * height

session = requests.Session()
response = session.get(f"{BASE_URL}/conference-registration/", timeout=20)
response.raise_for_status()
match = re.search(r'name="csrfmiddlewaretoken" value="([^"]+)"', response.text)
if not match:
    raise SystemExit("csrf token not found")

csrf = match.group(1)
image_bytes = bmp_bytes(10, 10)

files = {
    "avatar_photo": ("avatar.bmp", BytesIO(image_bytes), "image/bmp"),
    "payment_proof": ("proof.bmp", BytesIO(image_bytes), "image/bmp"),
}
data = {
    "csrfmiddlewaretoken": csrf,
    "full_name": "系统演练用户",
    "phone_number": "13800000000",
    "region": "北京",
    "organization": "DAXA Smoke Test",
    "department": "Operations",
    "job_title": "QA",
    "email": "events@daxa.ltd",
    "invoice_title": "DAXA Smoke Test",
    "invoice_tax_number": "TEST123456789",
    "notes": "会前自动演练记录",
    "payment_channel": "alipay",
    "consent_acknowledged": "on",
}
post = session.post(
    f"{BASE_URL}/conference-registration/",
    data=data,
    files=files,
    headers={"Referer": f"{BASE_URL}/conference-registration/"},
    allow_redirects=False,
    timeout=20,
)
print(post.status_code, post.headers.get("Location", ""))
if post.status_code != 302:
    raise SystemExit(post.text[:400])
PY

ssh "$REMOTE_HOST" "cd $REMOTE_APP_DIR && sudo -n docker-compose exec -T web python manage.py shell -c \"from meetings.models import MeetingRegistration; MeetingRegistration.objects.filter(organization='DAXA Smoke Test').delete()\""
