#!/bin/sh
set -eu

if [ "${1:-}" != "--as-wagtail" ] && [ "$(id -u)" -eq 0 ]; then
    mkdir -p /app/media /app/media/meeting-avatars /app/media/meeting-payment-proofs
    chown -R wagtail:wagtail /app/media
    chmod 775 /app/media /app/media/meeting-avatars /app/media/meeting-payment-proofs
    exec su -s /bin/sh wagtail -c "/app/scripts/entrypoint.sh --as-wagtail"
fi

mkdir -p /app/media /app/media/meeting-avatars /app/media/meeting-payment-proofs

python manage.py migrate --noinput
python manage.py shell -c "import os; from urllib.parse import urlparse; from wagtail.models import Site; base=os.environ.get('WAGTAILADMIN_BASE_URL', 'http://localhost'); parsed=urlparse(base); site=Site.objects.filter(is_default_site=True).first(); hostname=(parsed.hostname or 'localhost'); port=(parsed.port or (443 if parsed.scheme == 'https' else 80)); \
print(f'Configuring default site for {hostname}:{port}'); \
site.hostname=hostname; site.port=port; site.site_name='大下科技'; site.save()"
python manage.py collectstatic --noinput

exec gunicorn daxaone.wsgi:application \
    --bind 0.0.0.0:8000 \
    --workers 3 \
    --threads 2 \
    --timeout 90
