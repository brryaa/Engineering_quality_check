#!/usr/bin/env bash
set -euo pipefail

REMOTE_HOST="ubuntu@ph3.711177.xyz"
REMOTE_APP_DIR="/srv/daxa-newone"
LOCAL_ROOT="/home/brrr/codex/host-backups/newone"
STAMP="$(date +%Y%m%d-%H%M%S)"
MODE="${1:-all}"

mkdir -p "$LOCAL_ROOT/db" "$LOCAL_ROOT/media" "$LOCAL_ROOT/logs"

backup_db() {
    local target="$LOCAL_ROOT/db/db-${STAMP}.sql.gz"
    ssh "$REMOTE_HOST" "cd $REMOTE_APP_DIR && sudo -n docker-compose exec -T db sh -lc 'PGPASSWORD=\"\$POSTGRES_PASSWORD\" pg_dump -U \"\$POSTGRES_USER\" -d \"\$POSTGRES_DB\" --no-owner --no-privileges'" | gzip -c > "$target"
    ln -sfn "$target" "$LOCAL_ROOT/db/latest.sql.gz"
}

backup_media() {
    local target="$LOCAL_ROOT/media/media-${STAMP}.tar.gz"
    ssh "$REMOTE_HOST" "cd $REMOTE_APP_DIR && sudo -n docker-compose exec -T web sh -lc 'tar -C /app -czf - media'" > "$target"
    ln -sfn "$target" "$LOCAL_ROOT/media/latest.tar.gz"
}

prune_old() {
    find "$LOCAL_ROOT/db" -type f -name 'db-*.sql.gz' -mtime +30 -delete
    find "$LOCAL_ROOT/media" -type f -name 'media-*.tar.gz' -mtime +14 -delete
}

case "$MODE" in
    db)
        backup_db
        ;;
    media)
        backup_media
        ;;
    all)
        backup_db
        backup_media
        ;;
    *)
        echo "Usage: $0 [db|media|all]" >&2
        exit 1
        ;;
esac

prune_old
