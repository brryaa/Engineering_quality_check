# DAXA New One

Greenfield rebuild for `newone.daxa.ltd`.

Goals:

- Replace the current WordPress main site and `/sp/` subsystem with one codebase.
- Use a unified Wagtail admin for content and future workflow features.
- Launch on `newone.daxa.ltd` first, then cut over to `www.daxa.ltd`.

## Stack

- Wagtail / Django
- PostgreSQL
- Redis
- Docker Compose
- Apache reverse proxy on the current VPS

## Local development

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r rebuild/requirements.txt
cd rebuild
python manage.py migrate
python manage.py runserver
```

Use `daxaone.settings.dev` for local development.

## Production bootstrap

1. Copy `.env.example` to `.env` and fill in secrets.
2. Point `newone.daxa.ltd` to the VPS.
3. Run:

```bash
docker compose up --build -d
```

Default safe mode on the current VPS:

- `web` binds to `127.0.0.1:18080`
- Apache can reverse proxy `newone.daxa.ltd` to that local port
- Caddy config is kept under `infra/` for a later full edge cutover, but it is not part of the first VPS deployment

## Migration direction

- Main site pages and articles move into `sitecontent`.
- `/sp/` functionality moves into `workspace` models and Django views over time.
- Legacy routes can be tracked in the `workspace.LegacyRoute` snippet.
