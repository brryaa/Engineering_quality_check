from django.db import models
from django.shortcuts import redirect, render
from django.utils import timezone

from modelcluster.fields import ParentalKey
from wagtail.admin.panels import FieldPanel, InlinePanel, MultiFieldPanel
from wagtail.fields import RichTextField
from wagtail.models import Orderable, Page

from .forms import MeetingRegistrationForm


class MeetingRegistrationPage(Page):
    parent_page_types = ["home.HomePage"]
    subpage_types = []

    intro = models.CharField(max_length=160, default="“帷幄天下”系列报告会")
    hero_title = models.CharField(max_length=160, default='报名参会｜“帷幄天下”能源发展形势专题报告会')
    hero_summary = RichTextField(
        features=["bold", "italic", "link"],
        default=(
            "<p>快来参会 2025年04月27日 北京会议中心 6号楼 第2会议室。</p>"
            "<p>由中国企业改革与发展研究会主办、中国石油大学（北京）能源产业创新和转型发展研究中心协办、"
            "大下科技（北京）有限公司承办的能源发展形势专题报告会，将邀请能源领域权威专家，围绕“十五五”"
            "能源转型发展面临的形势和任务开展闭门交流。</p>"
        ),
    )
    event_highlight = models.CharField(max_length=160, default="2025年04月27日  09:00—18:00  北京会议中心 6号楼 第2会议室")
    meeting_time_text = models.CharField(max_length=120, default="2025年04月27日（周日） 09:00-18:00")
    venue = models.CharField(max_length=160, default="北京会议中心 6号楼 第2会议室")
    organizer = models.CharField(max_length=120, default="大下科技（北京）有限公司")
    contact_phone = models.CharField(max_length=40, blank=True, default="刘老师：18610079939（同微信）")
    contact_email = models.EmailField(blank=True, default="events@daxa.ltd")
    moderator_name = models.CharField(max_length=80, default="吕建中")
    moderator_bio = models.TextField(
        default="中国企业改革与发展研究会高级研究员\n中国石油大学（北京）特聘研究员\n中石油经济技术研究院原副院长"
    )
    moderator_image_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2243633",
    )
    handbook_url = models.URLField(blank=True, default="https://newone.daxa.ltd/conference-handbook/")
    alipay_qr_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2245505",
    )
    wechat_qr_url = models.URLField(blank=True, default="")
    host_units = RichTextField(
        blank=True,
        default=(
            "<p><strong>主办单位</strong></p>"
            "<p>中国企业改革与发展研究会</p>"
            "<p><strong>协办单位</strong></p>"
            "<p>中国石油大学（北京）能源产业创新和转型发展研究中心</p>"
            "<p><strong>承办单位</strong></p>"
            "<p>大下科技（北京）有限公司</p>"
        ),
    )
    agenda = RichTextField(
        blank=True,
        default=(
            "<p><strong>09:10 - 10:10</strong> 全球能源形势与展望</p>"
            "<p><strong>10:10 - 11:10</strong> 我国能源转型发展形势与展望</p>"
            "<p><strong>11:10 - 12:10</strong> 石油、天然气行业发展与展望</p>"
            "<p><strong>13:30 - 14:30</strong> 电力行业发展与展望</p>"
            "<p><strong>14:30 - 15:30</strong> 可再生能源行业发展与展望（含新能源、氢能、储能等）</p>"
            "<p><strong>15:45 - 16:45</strong> 能源行业数字化智能化发展</p>"
            "<p><strong>16:45 - 17:45</strong> 能源行业市场化改革及相关政策</p>"
        ),
    )
    payment_details = RichTextField(
        blank=True,
        default=(
            "<p><strong>会议费</strong> ￥2500/人</p>"
            "<p>本次会议由承办单位大下科技（北京）有限公司收取注册费并开具会议费发票。</p>"
            "<p><strong>银行汇款</strong></p>"
            "<p>户名：大下科技（北京）有限公司</p>"
            "<p>账号：0200064709200054063</p>"
            "<p>开户行：中国工商银行股份有限公司北京北京站支行</p>"
            "<p>支付完成后请保留转账凭证，汇款时请务必备注：姓名+公司名。</p>"
            "<p><strong>支付宝 / 微信支付</strong></p>"
            "<p>支付完成后请截图保存，并在支付界面备注：姓名+公司名。</p>"
        ),
    )
    confirmation_note = RichTextField(
        blank=True,
        default=(
            "<p>会务组在收到您填写的报名信息及会议费后，将在 1-3 个工作日内通过邮件向您发送确认信息，"
            "请留意您的邮箱。若未收到确认邮件，请与会务组联系。</p>"
        ),
    )
    contact_details = RichTextField(
        blank=True,
        default=(
            "<p>刘老师：+86 18610079939（同微信）</p>"
            "<p>姜老师：+86 13701135674</p>"
            "<p>E-mail：events@daxa.ltd</p>"
        ),
    )
    route_guide = RichTextField(
        blank=True,
        default=(
            "<p><strong>签到时间：</strong>08:00—09:00</p>"
            "<p><strong>签到地点：</strong>北京会议中心 6 号楼一楼大厅签到台，凭有效身份证件领取参会证。</p>"
            "<p><strong>目的地：</strong>北京会议中心，地址：北京市朝阳区来广营西路88号（北五环辅路），路线咨询电话 010-84901668。</p>"
        ),
    )
    attendance_notice = RichTextField(
        blank=True,
        default=(
            "<p>请所有参会人员遵守会场安全要求、健康与防疫提示以及现场管理安排。</p>"
            "<p>会务组为参会嘉宾提供餐券，请在签到时领取。就餐地点为 6 号楼一楼餐厅，就餐时间 12:30 - 13:30。</p>"
            "<p>会议室外茶歇台提供茶水和点心，茶歇时间 15:30 - 15:45。</p>"
        ),
    )
    invoice_and_hotel_note = RichTextField(
        blank=True,
        default=(
            "<p>会议费发票将在会议结束后由会务组统一开具，并将电子发票及会议通知发送至您报名时填写的邮箱。</p>"
            "<p>北京会议中心仅为参会嘉宾提供客房，协议价约 500—800 元，房费发票由北京会议中心客房部开具。</p>"
        ),
    )
    consent_copy = models.TextField(
        default=(
            "根据会议记录需求，您知悉并同意：主办方、协办方及承办方将在会议期间进行拍照及影像录制，"
            "您的肖像可能出现在相关素材中，并授权用于会议报道、活动宣传等合法用途。所有影像资料的版权归"
            "主办方及相关单位所有。若您对个人影像使用有特殊要求，请于会议前联系客服。"
        ),
    )
    success_message = models.CharField(max_length=200, default="提交成功，报名信息已收到。")
    privacy_note = models.CharField(
        max_length=200,
        default="请确保深灰色“提交成功”图标出现；否则请修改信息后再次提交。",
    )

    content_panels = Page.content_panels + [
        MultiFieldPanel(
            [
                FieldPanel("intro"),
                FieldPanel("hero_title"),
                FieldPanel("hero_summary"),
                FieldPanel("event_highlight"),
            ],
            heading="页面头部",
        ),
        MultiFieldPanel(
            [
                FieldPanel("meeting_time_text"),
                FieldPanel("venue"),
                FieldPanel("organizer"),
                FieldPanel("contact_phone"),
                FieldPanel("contact_email"),
                FieldPanel("moderator_name"),
                FieldPanel("moderator_bio"),
                FieldPanel("moderator_image_url"),
                FieldPanel("handbook_url"),
                FieldPanel("alipay_qr_url"),
                FieldPanel("host_units"),
                FieldPanel("agenda"),
                FieldPanel("payment_details"),
                FieldPanel("confirmation_note"),
                FieldPanel("contact_details"),
                FieldPanel("route_guide"),
                FieldPanel("attendance_notice"),
                FieldPanel("invoice_and_hotel_note"),
                FieldPanel("consent_copy"),
            ],
            heading="会议信息",
        ),
        InlinePanel("speaker_profiles", label="讲师介绍"),
        MultiFieldPanel(
            [
                FieldPanel("success_message"),
                FieldPanel("privacy_note"),
            ],
            heading="表单反馈",
        ),
    ]

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)
        context.setdefault("form", MeetingRegistrationForm())
        context["submission_count"] = self.registrations.count()
        context["latest_submission_at"] = self.registrations.order_by("-created_at").values_list("created_at", flat=True).first()
        context["success"] = request.GET.get("submitted") == "1"
        return context

    def serve(self, request, *args, **kwargs):
        if request.method == "POST":
            form = MeetingRegistrationForm(request.POST, request.FILES)
            if form.is_valid():
                MeetingRegistration.objects.create(page=self, **form.cleaned_data)
                return redirect(f"{self.url}?submitted=1")
            context = self.get_context(request, *args, **kwargs)
            context["form"] = form
            context["success"] = False
            return render(request, "meetings/meeting_registration_page.html", context)
        return super().serve(request, *args, **kwargs)


class MeetingRegistration(models.Model):
    page = models.ForeignKey(
        MeetingRegistrationPage,
        related_name="registrations",
        on_delete=models.CASCADE,
    )
    full_name = models.CharField("姓名", max_length=80)
    phone_number = models.CharField("电话", max_length=40)
    region = models.CharField("地区", max_length=120, default="")
    organization = models.CharField("公司 / 单位", max_length=120)
    department = models.CharField("部门", max_length=120, blank=True)
    job_title = models.CharField("职位", max_length=120, default="")
    email = models.EmailField("邮箱", default="")
    invoice_title = models.CharField("开票抬头", max_length=160, default="")
    invoice_tax_number = models.CharField("开票税号", max_length=80, default="")
    avatar_photo = models.ImageField("头像照", upload_to="meeting-avatars/", blank=True)
    notes = models.TextField("备注", blank=True)
    payment_channel = models.CharField("支付渠道", max_length=40, default="")
    payment_proof = models.ImageField("支付完成凭证", upload_to="meeting-payment-proofs/", blank=True)
    consent_acknowledged = models.BooleanField("同意参会须知", default=False)
    created_at = models.DateTimeField("提交时间", default=timezone.now, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "会议报名"
        verbose_name_plural = "会议报名"

    def __str__(self):
        return f"{self.full_name} - {self.organization}"


class SpeakerProfile(Orderable):
    page = ParentalKey(
        MeetingRegistrationPage,
        related_name="speaker_profiles",
        on_delete=models.CASCADE,
    )
    session_time = models.CharField("场次时间", max_length=40)
    topic = models.CharField("议题", max_length=160)
    speaker_name = models.CharField("讲师姓名", max_length=80)
    speaker_bio = models.TextField("讲师介绍")
    image_url = models.URLField("头像地址", blank=True)

    panels = [
        FieldPanel("session_time"),
        FieldPanel("topic"),
        FieldPanel("speaker_name"),
        FieldPanel("speaker_bio"),
        FieldPanel("image_url"),
    ]

    class Meta:
        ordering = ["sort_order"]
        verbose_name = "讲师介绍"
        verbose_name_plural = "讲师介绍"

    def __str__(self):
        return f"{self.session_time} {self.speaker_name}"


class MeetingHandbookPage(Page):
    parent_page_types = ["home.HomePage"]
    subpage_types = []

    intro = models.CharField(max_length=120, default="会议手册")
    title_text = models.CharField(max_length=160, default="“帷幄天下”能源发展形势专题报告会 会议手册")
    summary = RichTextField(
        blank=True,
        default=(
            "<p>手册页用于承接报名页底部的“查看会议手册”入口，集中整理签到、议程、交通、会务、发票和住宿信息。</p>"
        ),
    )
    hero_image_one_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2263474",
    )
    hero_image_two_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2256824",
    )
    hero_image_three_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2243059",
    )
    checkin_time = models.CharField(max_length=80, default="签到时间：08:00—09:00")
    checkin_details = RichTextField(
        blank=True,
        default=(
            "<p><strong>签到地点</strong></p>"
            "<p>北京会议中心6号楼<br>一楼大厅 签到台</p>"
            "<p>* 凭有效身份证件领取参会证<br>* 午餐券请在签到时领取</p>"
            "<p>注：进入北京会议中心时，告知岗亭安保人员参加“帷幄天下”的会议，即可放行，参会者停车免费。</p>"
        ),
    )
    morning_agenda = RichTextField(
        blank=True,
        default=(
            "<p><strong>会议主持</strong><br>吕建中<br>中国企业改革与发展研究会高级研究员<br>中国石油大学（北京）特聘研究员<br>中石油经济技术研究院原副院长</p>"
            "<p><strong>09:00 - 09:10</strong><br>开幕致辞<br>谭剑<br>中国企业改革与发展研究会副会长兼秘书长</p>"
            "<p><strong>09:10 - 10:10</strong><br>全球能源形势与展望<br>朱坤锋<br>国际知名咨询机构高级专家</p>"
            "<p><strong>10:10 - 11:10</strong><br>我国能源转型发展形势与展望<br>向海平<br>国家能源局原总工程师</p>"
            "<p><strong>11:10 - 12:10</strong><br>石油、天然气行业发展与展望<br>常毓文<br>中国石油勘探开发研究院原首席专家</p>"
        ),
    )
    lunch_details = RichTextField(
        blank=True,
        default=(
            "<p><strong>12:30 - 13:30</strong> 自助午餐</p>"
            "<p>北京会议中心 6号楼 一楼餐厅。会务组为参会嘉宾提供餐券，请在签到时领取。</p>"
        ),
    )
    afternoon_agenda = RichTextField(
        blank=True,
        default=(
            "<p><strong>13:30 - 14:30</strong><br>电力行业发展与展望<br>徐小东<br>电力规划设计总院原副院长</p>"
            "<p><strong>14:30 - 15:30</strong><br>可再生能源行业发展与展望（含新能源、氢能、储能等）<br>杨雷<br>北京大学能源研究院副院长<br>原国际能源署（IEA）署长高级顾问</p>"
            "<p><strong>15:30 - 15:45 茶歇</strong></p>"
            "<p><strong>15:45 - 16:45</strong><br>能源行业数字化智能化发展<br>肖立志<br>中国石油大学（北京）教授、<br>原人工智能学院院长</p>"
            "<p><strong>16:45 - 17:45</strong><br>能源行业市场化改革及相关政策<br>柴高峰<br>国网能源研究院原副院长</p>"
            "<p><strong>17:45 - 18:00</strong><br>闭幕总结<br>吕建中<br>中国企业改革与发展研究会高级研究员<br>中国石油大学（北京）特聘研究员<br>中石油经济技术研究院原副院长</p>"
        ),
    )
    transportation_details = RichTextField(
        blank=True,
        default=(
            "<p><strong>路线咨询电话 010-84901668</strong></p>"
            "<p><strong>1. 自驾车（免费停车）</strong><br>北五环自西向东，在仰山桥沿“北京会议中心”路标行驶，即可到达北门。<br><br>北五环自东向西，在顾家庄桥沿“北京会议中心”路标行驶，即可到达东门。<br><br>* 停车：告知岗亭安保人员参加“帷幄天下”的会议，进入北京会议中心找车位停即可。</p>"
            "<p><strong>2. 首都机场－北京会议中心</strong><br>出租车：机场高速至北五环，往西至顾家庄桥的“北京会议中心”出口，沿着路标行驶，即可从东门进入。<br><br>机场快轨：在T2航站楼乘坐机场快轨（airport express subway towards Dongzhimen）到达三元桥站，在三元桥站转地铁十号线（巴沟方向），在惠新西街南口转地铁五号线（天通苑北方向），到大屯路东站下车，搭乘569路公交车到北京会议中心站即可到达。也可在三元桥站直接搭乘出租车到达北京会议中心。</p>"
            "<p><strong>3. 北京大兴国际机场－北京会议中心</strong><br>出租车：<br>大兴机场高速经南五环、德贤路至南四环东路，经东四环南路到达北苑路，沿北苑路往北经过北五环辅路到达北京会议中心北门，即可从北门进入。<br>大兴机场高速经南五环、东五环、北五环到达顾家庄桥的“北京会议中心”出口，沿着路标行驶，即可从东门进入。<br><br>地铁线：在大兴机场地铁站乘坐地铁到达草桥站，在草桥站换乘地铁十九号线（牡丹园方向）到达牡丹园地铁站，在牡丹园地铁站换乘地铁十号线（健德门方向）到达惠新西街南口地铁站，在惠新西街南口转地铁五号线（天通苑北方向），到大屯路东站下车，搭乘569路公交车到北京会议中心站即可到达。</p>"
            "<p><strong>4. 火车站－北京会议中心</strong><br>北京西客站：换乘地铁七号线至磁器口站，换乘地铁五号线至大屯路东站B1（东北口），换乘569路至北京会议中心即可到达。<br><br>北京站：乘地铁二号线至崇文门站，换乘地铁五号线至大屯路东站B1（东北口），换乘569路至北京会议中心即可到达。<br><br>北京南站：乘地铁十四号线至蒲黄榆站，换乘地铁五号线至大屯路东站B1（东北口），换乘569路至北京会议中心即可到达。</p>"
            "<p><strong>5. 打车（出示地址信息给司机）</strong><br>目的地：北京会议中心<br>地址：北京市朝阳区来广营西路88号（北五环辅路）<br>电话：（010）84901668</p>"
        ),
    )
    notice_details = RichTextField(
        blank=True,
        default=(
            "<p>请全程佩戴会议证件，无证人员不得进入会场；配合安检，严禁携带危险物品。</p>"
            "<p>熟悉安全出口和应急路线；如遇紧急情况请听从工作人员指挥。</p>"
            "<p>谨慎连接公共 Wi-Fi，未经许可不得传播演讲内容或机密资料。</p>"
            "<p>如有身体不适请立即联系会务组，并遵守现场健康与防疫要求。</p>"
        ),
    )
    catering_details = RichTextField(
        blank=True,
        default=(
            "<p><strong>自助午餐</strong><br>* 会务组为参会嘉宾提供餐券，请在签到时领取。<br>* 就餐地点：6号楼一楼餐厅<br>* 就餐时间：12:30 - 13:30</p>"
            "<p><strong>茶歇</strong><br>* 会议室外的茶歇台<br>* 茶水和点心<br>* 茶歇时间：15:30 - 15:45</p>"
            "<p><strong>为了可持续未来</strong><br>* 请携带可重复使用的水杯 *</p>"
            "<p>尊敬的参会嘉宾：<br>会议室外茶歇台备有茶水。为了践行绿色可持续目标，本次会议鼓励大家自带可重复使用的水杯，当然，我们也会准备好充足的纸杯。<br>您的每一份小小行动，都是对地球的珍贵馈赠。感谢您为联合国可持续发展目标（SDGs）贡献力量，与我们共同守护绿色未来！<br><br>会务组 敬上</p>"
        ),
    )
    invoice_details = RichTextField(
        blank=True,
        default=(
            "<p><strong>会议费发票</strong><br>会议费发票将在会议结束后由会务组统一开具，会务组会将电子发票以及会议通知（红头文件）一并发送至您注册报名时留的电子邮箱。<br>会务组将使用 events@daxa.ltd 为您发送电子邮件。<br>如您在会议结束后7个工作日内未收到邮件，请与会务组刘老师联系，电话18610079939。</p>"
        ),
    )
    hotel_details = RichTextField(
        blank=True,
        default=(
            "<p>北京会议中心仅为参会嘉宾提供客房，非参会嘉宾不予接待。</p>"
            "<p>房间标准价：标准间 980 元/天，大床房 1280 元/天；协议价约 500—800 元。房费发票由北京会议中心客房部开具。</p>"
        ),
    )
    support_details = RichTextField(
        blank=True,
        default=(
            "<p>刘老师：18610079939（同微信）<br>姜老师：13701135674<br>E-mail：events@daxa.ltd</p>"
        ),
    )
    support_image_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2256855",
    )
    location_label = models.CharField(max_length=120, default="北京会议中心 6号楼（靠近北门）")
    map_image_url = models.URLField(
        blank=True,
        default="https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2256825",
    )
    registration_url = models.URLField(blank=True, default="https://newone.daxa.ltd/conference-registration/")
    home_url = models.URLField(blank=True, default="https://newone.daxa.ltd/")

    content_panels = Page.content_panels + [
        MultiFieldPanel(
            [
                FieldPanel("intro"),
                FieldPanel("title_text"),
                FieldPanel("summary"),
                FieldPanel("hero_image_one_url"),
                FieldPanel("hero_image_two_url"),
                FieldPanel("hero_image_three_url"),
                FieldPanel("checkin_time"),
                FieldPanel("checkin_details"),
                FieldPanel("morning_agenda"),
                FieldPanel("lunch_details"),
                FieldPanel("afternoon_agenda"),
                FieldPanel("transportation_details"),
                FieldPanel("notice_details"),
                FieldPanel("catering_details"),
                FieldPanel("invoice_details"),
                FieldPanel("hotel_details"),
                FieldPanel("support_details"),
                FieldPanel("support_image_url"),
                FieldPanel("location_label"),
                FieldPanel("map_image_url"),
                FieldPanel("registration_url"),
                FieldPanel("home_url"),
            ],
            heading="会议手册内容",
        ),
    ]
