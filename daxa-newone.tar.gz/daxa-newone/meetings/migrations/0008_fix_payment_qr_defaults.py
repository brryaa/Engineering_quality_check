from django.db import migrations, models


CORRECT_PAYMENT_QR = "https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2245505"
WRONG_PAYMENT_QRS = {
    "https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2245531",
    "https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2245530",
}


def fix_seeded_payment_qr(apps, schema_editor):
    MeetingRegistrationPage = apps.get_model("meetings", "MeetingRegistrationPage")
    for page in MeetingRegistrationPage.objects.all():
        if page.alipay_qr_url in WRONG_PAYMENT_QRS or not page.alipay_qr_url:
            page.alipay_qr_url = CORRECT_PAYMENT_QR
        if page.wechat_qr_url in WRONG_PAYMENT_QRS:
            page.wechat_qr_url = ""
        page.save(update_fields=["alipay_qr_url", "wechat_qr_url"])


class Migration(migrations.Migration):

    dependencies = [
        ("meetings", "0007_meetingregistrationpage_alipay_qr_url_and_more"),
    ]

    operations = [
        migrations.AlterField(
            model_name="meetingregistrationpage",
            name="alipay_qr_url",
            field=models.URLField(blank=True, default=CORRECT_PAYMENT_QR),
        ),
        migrations.AlterField(
            model_name="meetingregistrationpage",
            name="wechat_qr_url",
            field=models.URLField(blank=True, default=""),
        ),
        migrations.RunPython(fix_seeded_payment_qr, migrations.RunPython.noop),
    ]
