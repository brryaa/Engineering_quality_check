from django.db import migrations
import wagtail.fields


class Migration(migrations.Migration):

    dependencies = [
        ("meetings", "0010_sync_handbook_content_from_weda"),
    ]

    operations = [
        migrations.AlterField(
            model_name="meetinghandbookpage",
            name="afternoon_agenda",
            field=wagtail.fields.RichTextField(
                blank=True,
                default=(
                    "<p><strong>13:30 - 14:30</strong><br>电力行业发展与展望<br>徐小东<br>电力规划设计总院原副院长</p>"
                    "<p><strong>14:30 - 15:30</strong><br>可再生能源行业发展与展望（含新能源、氢能、储能等）<br>杨雷<br>北京大学能源研究院副院长<br>原国际能源署（IEA）署长高级顾问</p>"
                    "<p><strong>15:30 - 15:45 茶歇</strong></p>"
                    "<p><strong>15:45 - 16:45</strong><br>能源行业数字化智能化发展<br>肖立志<br>中国石油大学（北京）教授、<br>原人工智能学院院长</p>"
                    "<p><strong>16:45 - 17:45</strong><br>能源行业市场化改革及相关政策<br>柴高峰<br>国网能源研究院原副院长</p>"
                    "<p><strong>17:45 - 18:00</strong><br>闭幕总结<br>吕建中<br>中国企业改革与发展研究会高级研究员<br>中国石油大学（北京）特聘研究员<br>中石油经济技术研究院原副院长</p>"
                ),
            ),
        ),
        migrations.AlterField(
            model_name="meetinghandbookpage",
            name="catering_details",
            field=wagtail.fields.RichTextField(
                blank=True,
                default=(
                    "<p><strong>自助午餐</strong><br>* 会务组为参会嘉宾提供餐券，请在签到时领取。<br>* 就餐地点：6号楼一楼餐厅<br>* 就餐时间：12:30 - 13:30</p>"
                    "<p><strong>茶歇</strong><br>* 会议室外的茶歇台<br>* 茶水和点心<br>* 茶歇时间：15:30 - 15:45</p>"
                    "<p><strong>为了可持续未来</strong><br>* 请携带可重复使用的水杯 *</p>"
                    "<p>尊敬的参会嘉宾：<br>会议室外茶歇台备有茶水。为了践行绿色可持续目标，本次会议鼓励大家自带可重复使用的水杯，当然，我们也会准备好充足的纸杯。<br>您的每一份小小行动，都是对地球的珍贵馈赠。感谢您为联合国可持续发展目标（SDGs）贡献力量，与我们共同守护绿色未来！<br><br>会务组 敬上</p>"
                ),
            ),
        ),
        migrations.AlterField(
            model_name="meetinghandbookpage",
            name="checkin_details",
            field=wagtail.fields.RichTextField(
                blank=True,
                default=(
                    "<p><strong>签到地点</strong></p>"
                    "<p>北京会议中心6号楼<br>一楼大厅 签到台</p>"
                    "<p>* 凭有效身份证件领取参会证<br>* 午餐券请在签到时领取</p>"
                    "<p>注：进入北京会议中心时，告知岗亭安保人员参加“帷幄天下”的会议，即可放行，参会者停车免费。</p>"
                ),
            ),
        ),
        migrations.AlterField(
            model_name="meetinghandbookpage",
            name="invoice_details",
            field=wagtail.fields.RichTextField(
                blank=True,
                default=(
                    "<p><strong>会议费发票</strong><br>会议费发票将在会议结束后由会务组统一开具，会务组会将电子发票以及会议通知（红头文件）一并发送至您注册报名时留的电子邮箱。<br>会务组将使用 events@daxa.ltd 为您发送电子邮件。<br>如您在会议结束后7个工作日内未收到邮件，请与会务组刘老师联系，电话18610079939。</p>"
                ),
            ),
        ),
        migrations.AlterField(
            model_name="meetinghandbookpage",
            name="morning_agenda",
            field=wagtail.fields.RichTextField(
                blank=True,
                default=(
                    "<p><strong>会议主持</strong><br>吕建中<br>中国企业改革与发展研究会高级研究员<br>中国石油大学（北京）特聘研究员<br>中石油经济技术研究院原副院长</p>"
                    "<p><strong>09:00 - 09:10</strong><br>开幕致辞<br>谭剑<br>中国企业改革与发展研究会副会长兼秘书长</p>"
                    "<p><strong>09:10 - 10:10</strong><br>全球能源形势与展望<br>朱坤锋<br>国际知名咨询机构高级专家</p>"
                    "<p><strong>10:10 - 11:10</strong><br>我国能源转型发展形势与展望<br>向海平<br>国家能源局原总工程师</p>"
                    "<p><strong>11:10 - 12:10</strong><br>石油、天然气行业发展与展望<br>常毓文<br>中国石油勘探开发研究院原首席专家</p>"
                ),
            ),
        ),
        migrations.AlterField(
            model_name="meetinghandbookpage",
            name="transportation_details",
            field=wagtail.fields.RichTextField(
                blank=True,
                default=(
                    "<p><strong>路线咨询电话 010-84901668</strong></p>"
                    "<p><strong>1. 自驾车（免费停车）</strong><br>北五环自西向东，在仰山桥沿“北京会议中心”路标行驶，即可到达北门。<br><br>北五环自东向西，在顾家庄桥沿“北京会议中心”路标行驶，即可到达东门。<br><br>* 停车：告知岗亭安保人员参加“帷幄天下”的会议，进入北京会议中心找车位停即可。</p>"
                    "<p><strong>2. 首都机场－北京会议中心</strong><br>出租车：机场高速至北五环，往西至顾家庄桥的“北京会议中心”出口，沿着路标行驶，即可从东门进入。<br><br>机场快轨：在T2航站楼乘坐机场快轨（airport express subway towards Dongzhimen）到达三元桥站，在三元桥站转地铁十号线（巴沟方向），在惠新西街南口转地铁五号线（天通苑北方向），到大屯路东站下车，搭乘569路公交车到北京会议中心站即可到达。也可在三元桥站直接搭乘出租车到达北京会议中心。</p>"
                    "<p><strong>3. 北京大兴国际机场－北京会议中心</strong><br>出租车：<br>大兴机场高速经南五环、德贤路至南四环东路，经东四环南路到达北苑路，沿北苑路往北经过北五环辅路到达北京会议中心北门，即可从北门进入。<br>大兴机场高速经南五环、东五环、北五环到达顾家庄桥的“北京会议中心”出口，沿着路标行驶，即可从东门进入。<br><br>地铁线：在大兴机场地铁站乘坐地铁到达草桥站，在草桥站换乘地铁十九号线（牡丹园方向）到达牡丹园地铁站，在牡丹园地铁站换乘地铁十号线（健德门方向）到达惠新西街南口地铁站，在惠新西街南口转地铁五号线（天通苑北方向），到大屯路东站下车，搭乘569路公交车到北京会议中心站即可到达。</p>"
                    "<p><strong>4. 火车站－北京会议中心</strong><br>北京西客站：换乘地铁七号线至磁器口站，换乘地铁五号线至大屯路东站B1（东北口），换乘569路至北京会议中心即可到达。<br><br>北京站：乘地铁二号线至崇文门站，换乘地铁五号线至大屯路东站B1（东北口），换乘569路至北京会议中心即可到达。<br><br>北京南站：乘地铁十四号线至蒲黄榆站，换乘地铁五号线至大屯路东站B1（东北口），换乘569路至北京会议中心即可到达。</p>"
                    "<p><strong>5. 打车（出示地址信息给司机）</strong><br>目的地：北京会议中心<br>地址：北京市朝阳区来广营西路88号（北五环辅路）<br>电话：（010）84901668</p>"
                ),
            ),
        ),
    ]
