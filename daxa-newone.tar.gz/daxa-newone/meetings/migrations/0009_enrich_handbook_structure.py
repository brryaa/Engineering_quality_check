from django.db import migrations, models


HERO_ONE = "https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2263474"
HERO_TWO = "https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2256824"
HERO_THREE = "https://cloud1-4g72v2aq5fe4d850-1353512829.tcloudbaseapp.com/resources/2025-04/lowcode-2243059"
REGISTRATION_URL = "https://newone.daxa.ltd/conference-registration/"
HOME_URL = "https://newone.daxa.ltd/"


def seed_handbook_structure(apps, schema_editor):
    MeetingHandbookPage = apps.get_model("meetings", "MeetingHandbookPage")
    for page in MeetingHandbookPage.objects.all():
        if not page.hero_image_one_url:
            page.hero_image_one_url = HERO_ONE
        if not page.hero_image_two_url:
            page.hero_image_two_url = HERO_TWO
        if not page.hero_image_three_url:
            page.hero_image_three_url = HERO_THREE
        if not page.registration_url:
            page.registration_url = REGISTRATION_URL
        if not page.home_url:
            page.home_url = HOME_URL
        page.save(
            update_fields=[
                "hero_image_one_url",
                "hero_image_two_url",
                "hero_image_three_url",
                "registration_url",
                "home_url",
            ]
        )


class Migration(migrations.Migration):

    dependencies = [
        ("meetings", "0008_fix_payment_qr_defaults"),
    ]

    operations = [
        migrations.AddField(
            model_name="meetinghandbookpage",
            name="hero_image_one_url",
            field=models.URLField(blank=True, default=HERO_ONE),
        ),
        migrations.AddField(
            model_name="meetinghandbookpage",
            name="hero_image_two_url",
            field=models.URLField(blank=True, default=HERO_TWO),
        ),
        migrations.AddField(
            model_name="meetinghandbookpage",
            name="hero_image_three_url",
            field=models.URLField(blank=True, default=HERO_THREE),
        ),
        migrations.AddField(
            model_name="meetinghandbookpage",
            name="home_url",
            field=models.URLField(blank=True, default=HOME_URL),
        ),
        migrations.AddField(
            model_name="meetinghandbookpage",
            name="registration_url",
            field=models.URLField(blank=True, default=REGISTRATION_URL),
        ),
        migrations.RunPython(seed_handbook_structure, migrations.RunPython.noop),
    ]
