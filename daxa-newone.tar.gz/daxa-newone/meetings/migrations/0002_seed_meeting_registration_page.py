from django.db import migrations


def seed_meeting_registration_page(apps, schema_editor):
    from home.models import HomePage
    from meetings.models import MeetingRegistrationPage

    homepage = HomePage.objects.filter(slug="home", depth=2).first()
    if not homepage:
        return

    homepage.primary_cta_label = "会议报名"
    homepage.primary_cta_url = "https://newone.daxa.ltd/conference-registration/"
    homepage.save(update_fields=["primary_cta_label", "primary_cta_url"])

    if MeetingRegistrationPage.objects.filter(slug="conference-registration").exists():
        return

    registration_page = MeetingRegistrationPage(
        title="会议报名",
        slug="conference-registration",
        intro="会议报名",
        hero_title="帷幄天下能源发展报告会",
        meeting_time_text="2026-04-20 09:00 - 17:30",
        venue="上海市浦东新区张江路 88 号",
        organizer="DAXA 会务组",
        contact_phone="+86 138 0000 0000",
        contact_email="events@daxa.ltd",
    )
    homepage.add_child(instance=registration_page)
    registration_page.save_revision().publish()


class Migration(migrations.Migration):
    dependencies = [
        ("meetings", "0001_initial"),
        ("home", "0005_alter_homepage_primary_cta_label_and_more"),
    ]

    operations = [
        migrations.RunPython(seed_meeting_registration_page, migrations.RunPython.noop),
    ]
