from django.db import migrations, models
import wagtail.fields


HERO_SUMMARY = (
    "<p>快来参会 2025年04月27日 北京会议中心 6号楼 第2会议室。</p>"
    "<p>由中国企业改革与发展研究会主办、中国石油大学（北京）能源产业创新和转型发展研究中心协办、"
    "大下科技（北京）有限公司承办的能源发展形势专题报告会，将邀请能源领域权威专家，围绕“十五五”"
    "能源转型发展面临的形势和任务开展闭门交流。</p>"
)

EVENT_HIGHLIGHT = "2025年04月27日  09:00—18:00  北京会议中心 6号楼 第2会议室"
MEETING_TIME_TEXT = "2025年04月27日（周日） 09:00-18:00"
VENUE = "北京会议中心 6号楼 第2会议室"


def sync_registration_event_meta(apps, schema_editor):
    MeetingRegistrationPage = apps.get_model("meetings", "MeetingRegistrationPage")
    for page in MeetingRegistrationPage.objects.all():
        page.hero_summary = HERO_SUMMARY
        page.event_highlight = EVENT_HIGHLIGHT
        page.meeting_time_text = MEETING_TIME_TEXT
        page.venue = VENUE
        page.save(update_fields=["hero_summary", "event_highlight", "meeting_time_text", "venue"])


class Migration(migrations.Migration):

    dependencies = [
        ("meetings", "0011_alter_meetinghandbookpage_defaults"),
    ]

    operations = [
        migrations.AlterField(
            model_name="meetingregistrationpage",
            name="hero_summary",
            field=wagtail.fields.RichTextField(
                default=HERO_SUMMARY,
                features=["bold", "italic", "link"],
            ),
        ),
        migrations.AlterField(
            model_name="meetingregistrationpage",
            name="event_highlight",
            field=models.CharField(max_length=160, default=EVENT_HIGHLIGHT),
        ),
        migrations.AlterField(
            model_name="meetingregistrationpage",
            name="meeting_time_text",
            field=models.CharField(max_length=120, default=MEETING_TIME_TEXT),
        ),
        migrations.AlterField(
            model_name="meetingregistrationpage",
            name="venue",
            field=models.CharField(max_length=160, default=VENUE),
        ),
        migrations.RunPython(sync_registration_event_meta, migrations.RunPython.noop),
    ]
