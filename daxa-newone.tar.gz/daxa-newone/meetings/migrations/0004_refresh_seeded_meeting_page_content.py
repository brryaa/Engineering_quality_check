from django.db import migrations


def refresh_meeting_page_content(apps, schema_editor):
    MeetingRegistrationPage = apps.get_model("meetings", "MeetingRegistrationPage")

    page = MeetingRegistrationPage.objects.filter(slug="conference-registration").first()
    if not page:
        return

    page.intro = "“帷幄天下”系列报告会"
    page.hero_title = '报名参会｜“帷幄天下”能源发展形势专题报告会'
    page.hero_summary = (
        "<p>快来参会 04月27日 北京会议中心。</p>"
        "<p>由中国企业改革与发展研究会主办、中国石油大学（北京）能源产业创新和转型发展研究中心协办、"
        "大下科技（北京）有限公司承办的能源发展形势专题报告会，将邀请能源领域权威专家，围绕“十五五”"
        "能源转型发展面临的形势和任务开展闭门交流。</p>"
    )
    page.event_highlight = "快来参会  04月27日  北京会议中心"
    page.meeting_time_text = "2026-04-27 09:00 - 17:45"
    page.venue = "北京市朝阳区来广营西路 88 号（近北五环）"
    page.organizer = "大下科技（北京）有限公司"
    page.contact_phone = "刘老师：18610079939（同微信）"
    page.contact_email = "events@daxa.ltd"
    page.host_units = (
        "<p><strong>主办单位</strong><br>中国企业改革与发展研究会</p>"
        "<p><strong>协办单位</strong><br>中国石油大学（北京）能源产业创新和转型发展研究中心</p>"
        "<p><strong>承办单位</strong><br>大下科技（北京）有限公司</p>"
    )
    page.agenda = (
        "<p><strong>09:10 - 10:10</strong> 全球能源形势与展望</p>"
        "<p><strong>10:10 - 11:10</strong> 我国能源转型发展形势与展望</p>"
        "<p><strong>11:10 - 12:10</strong> 石油、天然气行业发展与展望</p>"
        "<p><strong>13:30 - 14:30</strong> 电力行业发展与展望</p>"
        "<p><strong>14:30 - 15:30</strong> 可再生能源行业发展与展望（含新能源、氢能、储能等）</p>"
        "<p><strong>15:45 - 16:45</strong> 能源行业数字化智能化发展</p>"
        "<p><strong>16:45 - 17:45</strong> 能源行业市场化改革及相关政策</p>"
    )
    page.payment_details = (
        "<p><strong>会议费</strong> ￥2500/人</p>"
        "<p>本次会议由承办单位大下科技（北京）有限公司收取注册费并开具会议费发票。</p>"
        "<p><strong>银行汇款</strong><br>"
        "户名：大下科技（北京）有限公司<br>"
        "账号：0200064709200054063<br>"
        "开户行：中国工商银行股份有限公司北京北京站支行</p>"
        "<p>支付完成后请保留转账凭证，汇款时请务必备注：姓名+公司名。</p>"
        "<p><strong>支付宝 / 微信支付</strong><br>支付完成后请截图保存，并在支付界面备注：姓名+公司名。</p>"
    )
    page.confirmation_note = (
        "<p>会务组在收到您填写的报名信息及会议费后，将在 1-3 个工作日内通过邮件向您发送确认信息，"
        "请留意您的邮箱。若未收到确认邮件，请与会务组联系。</p>"
    )
    page.contact_details = (
        "<p>刘老师：+86 18610079939（同微信）<br>"
        "姜老师：+86 13701135674<br>"
        "E-mail：events@daxa.ltd</p>"
    )
    page.route_guide = (
        "<p><strong>签到时间：</strong>08:00—09:00</p>"
        "<p><strong>签到地点：</strong>北京会议中心 6 号楼一楼大厅签到台，凭有效身份证件领取参会证。</p>"
        "<p><strong>目的地：</strong>北京会议中心，地址：北京市朝阳区来广营西路88号（北五环辅路），路线咨询电话 010-84901668。</p>"
    )
    page.attendance_notice = (
        "<p>请所有参会人员遵守会场安全要求、健康与防疫提示以及现场管理安排。</p>"
        "<p>会务组为参会嘉宾提供餐券，请在签到时领取。就餐地点为 6 号楼一楼餐厅，就餐时间 12:30 - 13:30。</p>"
        "<p>会议室外茶歇台提供茶水和点心，茶歇时间 15:30 - 15:45。</p>"
    )
    page.invoice_and_hotel_note = (
        "<p>会议费发票将在会议结束后由会务组统一开具，并将电子发票及会议通知发送至您报名时填写的邮箱。</p>"
        "<p>北京会议中心仅为参会嘉宾提供客房，协议价约 500—800 元，房费发票由北京会议中心客房部开具。</p>"
    )
    page.consent_copy = (
        "根据会议记录需求，您知悉并同意：主办方、协办方及承办方将在会议期间进行拍照及影像录制，"
        "您的肖像可能出现在相关素材中，并授权用于会议报道、活动宣传等合法用途。所有影像资料的版权归"
        "主办方及相关单位所有。若您对个人影像使用有特殊要求，请于会议前联系客服。"
    )
    page.success_message = "提交成功，报名信息已收到。"
    page.privacy_note = "请确保深灰色“提交成功”图标出现；否则请修改信息后再次提交。"
    page.save()


class Migration(migrations.Migration):
    dependencies = [
        ("meetings", "0003_remove_meetingregistration_attendance_slot_and_more"),
    ]

    operations = [
        migrations.RunPython(refresh_meeting_page_content, migrations.RunPython.noop),
    ]
