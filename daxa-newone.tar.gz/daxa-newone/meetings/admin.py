import csv

from django.contrib import admin
from django.http import HttpResponse

from .models import MeetingRegistration


@admin.register(MeetingRegistration)
class MeetingRegistrationAdmin(admin.ModelAdmin):
    list_display = (
        "full_name",
        "organization",
        "phone_number",
        "region",
        "job_title",
        "email",
        "payment_channel",
        "created_at",
    )
    list_filter = ("payment_channel", "consent_acknowledged", "created_at")
    search_fields = ("full_name", "organization", "phone_number", "email", "invoice_title", "invoice_tax_number")
    readonly_fields = ("created_at",)
    actions = ("export_as_csv",)

    @admin.action(description="导出选中报名为 CSV")
    def export_as_csv(self, request, queryset):
        response = HttpResponse(content_type="text/csv; charset=utf-8-sig")
        response["Content-Disposition"] = 'attachment; filename="meeting-registrations.csv"'

        writer = csv.writer(response)
        writer.writerow(
            [
                "姓名",
                "电话",
                "地区",
                "公司/单位",
                "部门",
                "职位",
                "邮箱",
                "开票抬头",
                "开票税号",
                "支付渠道",
                "同意参会须知",
                "备注",
                "头像照",
                "支付凭证",
                "提交时间",
            ]
        )

        for item in queryset:
            writer.writerow(
                [
                    item.full_name,
                    item.phone_number,
                    item.region,
                    item.organization,
                    item.department,
                    item.job_title,
                    item.email,
                    item.invoice_title,
                    item.invoice_tax_number,
                    item.payment_channel,
                    "是" if item.consent_acknowledged else "否",
                    item.notes,
                    item.avatar_photo.url if item.avatar_photo else "",
                    item.payment_proof.url if item.payment_proof else "",
                    item.created_at.isoformat(),
                ]
            )

        return response
