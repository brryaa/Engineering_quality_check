from django import forms
from django.core.exceptions import ValidationError


AVATAR_MAX_BYTES = 500 * 1024
PAYMENT_PROOF_MAX_BYTES = 2 * 1024 * 1024


def validate_file_size(upload, *, max_bytes, label):
    if upload and upload.size > max_bytes:
        limit_kb = max_bytes // 1024
        raise ValidationError(f"{label}不能超过 {limit_kb} KB。")


class MeetingRegistrationForm(forms.Form):
    PAYMENT_CHANNEL_CHOICES = [
        ("bank_transfer", "银行汇款"),
        ("alipay", "支付宝"),
        ("wechat_pay", "微信支付"),
    ]

    full_name = forms.CharField(label="姓名", max_length=80)
    phone_number = forms.CharField(label="电话", max_length=40)
    region = forms.CharField(label="地区", max_length=120)
    organization = forms.CharField(label="公司/单位", max_length=120)
    department = forms.CharField(label="部门", max_length=120, required=False)
    job_title = forms.CharField(label="职位", max_length=120)
    email = forms.EmailField(label="邮箱")
    invoice_title = forms.CharField(label="开票抬头", max_length=160)
    invoice_tax_number = forms.CharField(label="开票税号", max_length=80)
    avatar_photo = forms.ImageField(label="头像照", required=False)
    notes = forms.CharField(
        label="备注",
        required=False,
        widget=forms.Textarea(attrs={"rows": 4}),
    )
    payment_channel = forms.ChoiceField(label="支付渠道", choices=PAYMENT_CHANNEL_CHOICES)
    payment_proof = forms.ImageField(label="支付完成凭证")
    consent_acknowledged = forms.BooleanField(label="我同意参会须知", required=True)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        placeholders = {
            "full_name": "请输入真实姓名",
            "phone_number": "请输入手机号",
            "region": "请选择地区或填写地区",
            "organization": "请输入公司/单位",
            "department": "请输入所在部门",
            "job_title": "请输入您的职位",
            "email": "接收参会确认邮件和发票用",
            "invoice_title": "请输入抬头",
            "invoice_tax_number": "请输入税号",
            "notes": "如需会务组帮助，请备注",
        }
        for name, field in self.fields.items():
            css = "meeting-input"
            if isinstance(field.widget, forms.Textarea):
                field.widget.attrs["class"] = f"{css} meeting-textarea"
            elif isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs["class"] = "meeting-checkbox"
            elif isinstance(field.widget, forms.Select):
                field.widget.attrs["class"] = f"{css} meeting-select"
            else:
                field.widget.attrs["class"] = css
            if name in placeholders and not isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs["placeholder"] = placeholders[name]
            if isinstance(field.widget, forms.FileInput):
                field.widget.attrs["accept"] = "image/*"
        self.fields["avatar_photo"].help_text = "图片格式，大小不超过 500 KB。"
        self.fields["payment_proof"].help_text = "图片格式，大小不超过 2 MB。"

    def clean_avatar_photo(self):
        avatar_photo = self.cleaned_data.get("avatar_photo")
        validate_file_size(avatar_photo, max_bytes=AVATAR_MAX_BYTES, label="头像照")
        return avatar_photo

    def clean_payment_proof(self):
        payment_proof = self.cleaned_data.get("payment_proof")
        validate_file_size(payment_proof, max_bytes=PAYMENT_PROOF_MAX_BYTES, label="支付完成凭证")
        return payment_proof
