import re
from html import unescape
from datetime import date
from urllib.parse import unquote
from urllib.request import urlopen

from django.core.management.base import BaseCommand
from wagtail.models import Page

from home.models import HomePage
from sitecontent.models import ArticleIndexPage, ArticlePage, StandardPage


WP_API_BASE = "https://www.daxa.ltd/wp-json/wp/v2"

PAGE_MAPPINGS = [
    {"id": 30, "slug": "thinktank", "title": "大下智库"},
    {"id": 2, "slug": "contact-us", "title": "联系我们"},
]


def fetch_json(url):
    with urlopen(url) as response:
        return __import__("json").load(response)


def strip_tags(html):
    text = re.sub(r"<[^>]+>", "", html or "")
    text = text.replace("\xa0", " ")
    return re.sub(r"\s+", " ", unescape(text)).strip()


class Command(BaseCommand):
    help = "Import core pages and posts from the legacy WordPress site into Wagtail."

    def add_arguments(self, parser):
        parser.add_argument("--base-url", default=WP_API_BASE)

    def handle(self, *args, **options):
        base_url = options["base_url"].rstrip("/")
        home_page = HomePage.objects.live().first()
        if not home_page:
            raise RuntimeError("HomePage not found. Seed the site before importing content.")

        self.import_pages(base_url, home_page)
        article_index = self.import_article_index(home_page)
        self.import_posts(base_url, article_index)
        self.stdout.write(self.style.SUCCESS("Legacy WordPress content import finished."))

    def import_pages(self, base_url, home_page):
        for mapping in PAGE_MAPPINGS:
            item = fetch_json(f"{base_url}/pages/{mapping['id']}")
            page = StandardPage.objects.child_of(home_page).filter(slug=mapping["slug"]).first()
            if page is None:
                page = StandardPage(
                    title=mapping["title"],
                    slug=mapping["slug"],
                )
                home_page.add_child(instance=page)

            page.title = mapping["title"]
            page.intro = strip_tags(item["excerpt"]["rendered"])[:280]
            page.body = item["content"]["rendered"]
            page.save_revision().publish()
            self.stdout.write(f"Imported page: {page.slug}")

    def import_article_index(self, home_page):
        page = ArticleIndexPage.objects.child_of(home_page).filter(slug="articles").first()
        if page is None:
            page = ArticleIndexPage(title="最新消息", slug="articles", intro="旧站文章将逐步迁入这里，按发布时间和主题重组。")
            home_page.add_child(instance=page)
        page.title = "最新消息"
        page.intro = "旧站文章将逐步迁入这里，按发布时间和主题重组。"
        page.save_revision().publish()
        return ArticleIndexPage.objects.get(pk=page.pk)

    def import_posts(self, base_url, article_index):
        expected_children = Page.objects.filter(
            path__startswith=article_index.path,
            depth=article_index.depth + 1,
        ).count()
        if article_index.numchild != expected_children:
            article_index.numchild = expected_children
            article_index.save(update_fields=["numchild"])

        posts = fetch_json(f"{base_url}/posts?per_page=20")
        for item in posts:
            decoded_slug = unquote(item["slug"])
            slug = decoded_slug if re.fullmatch(r"[a-z0-9-]+", decoded_slug or "") else f"post-{item['id']}"
            title = strip_tags(item["title"]["rendered"])
            summary = strip_tags(item["excerpt"]["rendered"])[:400]
            body = item["content"]["rendered"]
            published_date = date.fromisoformat(item["date"][:10])
            page = ArticlePage.objects.child_of(article_index).filter(slug=slug).first()
            if page is None:
                page = ArticlePage(
                    title=title,
                    slug=slug,
                    date=published_date,
                    summary=summary,
                    body=body,
                )
                article_index.add_child(instance=page)

            page.title = title
            page.date = published_date
            page.summary = summary
            page.body = body
            page.save_revision().publish()
            self.stdout.write(f"Imported post: {page.slug}")
