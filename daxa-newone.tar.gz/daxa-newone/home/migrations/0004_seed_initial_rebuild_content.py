from django.db import migrations


def seed_initial_content(apps, schema_editor):
    HomePage = apps.get_model("home", "HomePage")
    HomeHighlight = apps.get_model("home", "HomeHighlight")
    HomeCapability = apps.get_model("home", "HomeCapability")
    HomeMigrationPhase = apps.get_model("home", "HomeMigrationPhase")

    homepage = HomePage.objects.filter(slug="home", depth=2).first()
    if not homepage:
        return

    if not HomeHighlight.objects.filter(page=homepage).exists():
        HomeHighlight.objects.bulk_create(
            [
                HomeHighlight(page=homepage, label="运行目标", value="单系统", note="内容与业务后台统一"),
                HomeHighlight(page=homepage, label="首发域名", value="newone.daxa.ltd", note="验证后切到主域名"),
                HomeHighlight(page=homepage, label="迁移范围", value="主站 + /sp/", note="只迁内容与功能，不迁旧主题"),
            ]
        )

    if not HomeCapability.objects.filter(page=homepage).exists():
        HomeCapability.objects.bulk_create(
            [
                HomeCapability(page=homepage, eyebrow="Content", title="官网与文章统一管理", description="主站页面、文章、专题内容改成一套结构化模型，不再依赖 WordPress 主题和 builder。"),
                HomeCapability(page=homepage, eyebrow="Workspace", title="吸收原 sp 的实用能力", description="把 /sp/ 中真正有价值的工作流改写成 Django 模块，统一进同一个后台。"),
                HomeCapability(page=homepage, eyebrow="Operations", title="迁移、跳转、功能状态可追踪", description="通过 snippet 和后台模型追踪旧路径映射、迁移状态和功能上线顺序。"),
            ]
        )

    if not HomeMigrationPhase.objects.filter(page=homepage).exists():
        HomeMigrationPhase.objects.bulk_create(
            [
                HomeMigrationPhase(page=homepage, phase="Phase 01", title="新站骨架上线", description="先在 newone.daxa.ltd 建立可运行的新系统、后台和首页。"),
                HomeMigrationPhase(page=homepage, phase="Phase 02", title="主站内容迁移", description="把旧主站文章、固定页面和栏目结构迁移进 sitecontent。"),
                HomeMigrationPhase(page=homepage, phase="Phase 03", title="sp 功能整合", description="逐个把原 /sp/ 中真正好用的功能改写成统一模块，再切换主域名。"),
            ]
        )

class Migration(migrations.Migration):
    dependencies = [
        ("sitecontent", "0001_initial"),
        ("home", "0003_homepage_hero_intro_homepage_hero_kicker_and_more"),
    ]

    operations = [
        migrations.RunPython(seed_initial_content, migrations.RunPython.noop),
    ]
