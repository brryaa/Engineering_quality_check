from django.core.management.base import BaseCommand

from home.models import HomeHighlight, HomeMigrationPhase, HomePage
from sitecontent.models import ArticleIndexPage, StandardPage
from workspace.models import WorkspaceModule


HOMEPAGE_FIELDS = {
    "hero_kicker": "服务天下",
    "hero_title": "研究、数据、活动与能力建设，在同一平台协同呈现。",
    "hero_intro": (
        "<p>大下科技围绕能源与气候、汽车与交通、国际合作等主题，持续提供研究内容、"
        "数据支持、活动组织与专题服务。</p>"
    ),
    "primary_cta_label": "会议报名",
    "primary_cta_url": "https://newone.daxa.ltd/conference-registration/",
    "secondary_cta_label": "查看频道",
    "secondary_cta_url": "https://newone.daxa.ltd/workspace/",
    "status_note": "聚焦研究判断、数据服务、国际会议与专题合作。",
    "migration_summary": (
        "<p>站点内容围绕研究频道、数据能力、活动组织和专题服务展开，"
        "让文章、页面与业务入口在同一内容体系中协同更新。</p>"
    ),
}

HIGHLIGHT_SPECS = [
    ("核心主题", "4 大方向", "研究、数据、活动与能力建设协同呈现"),
    ("主要域名", "newone.daxa.ltd", "统一承载公开内容与业务入口"),
    ("内容结构", "频道 + 页面 + 文章", "围绕议题组织内容，围绕场景组织服务"),
]

APPROACH_SPECS = [
    ("01", "研究内容组织", "围绕重点主题持续发布观察文章、专题解读与公开内容。"),
    ("02", "数据与专题服务", "通过数据页面、研究支持和专题服务说明清晰呈现合作方式。"),
    ("03", "活动与交流组织", "以会议、论坛、会务信息和议题内容形成完整活动体验。"),
]

ARTICLE_INDEX_INTRO = "集中呈现观察文章、专题解读与活动相关内容。"

STANDARD_PAGE_COPY = {
    "thinktank": {
        "intro": "围绕重点议题、研究观察与合作主题组织公开表达和内容输出。",
        "body": (
            "<p>大下智库聚焦能源与气候、汽车与交通、跨文化交流与国际合作等方向，"
            "通过文章、专题页和活动议题持续输出研究判断。</p>"
            "<p>这一页面适合承接研究主题说明、公开内容入口和合作方向介绍，"
            "保持简洁、稳定且便于继续扩展。</p>"
        ),
    },
    "contact-us": {
        "intro": "提供搜索、内容浏览、活动报名与业务页面的统一联系入口。",
        "body": (
            "<p>联系我们页面用于帮助访问者快速进入所需内容与业务场景。"
            "如果希望查找文章、专题页、活动信息或具体服务方向，"
            "可以从这里进入对应频道。</p>"
            "<p>页面重点保留搜索、文章与活动入口，让内容查找和业务触达保持清晰直接。</p>"
        ),
    },
}

MODULE_SUMMARIES = {
    "industry-reports": "围绕重点行业与政策主题输出研究观察、专题判断与建议内容。",
    "executive-forums": "聚合国际会议、高端论坛与闭门交流相关内容，连接报名与会务入口。",
    "training-workshops": "面向训练营、工作坊与专题培训场景，组织能力建设类服务内容。",
    "project-consulting": "围绕项目诊断、方案设计与执行协同，呈现咨询类合作方式。",
    "standards-development": "围绕标准议题、方法设计与行业协作，形成清晰的能力说明。",
    "database-subscription": "介绍数据订阅服务、适用对象与配套研究支持的核心内容。",
    "focus-energy-climate": "聚焦能源转型、气候治理与绿色投资等长期研究主题。",
    "focus-auto-transport": "聚焦汽车产业、交通体系与区域市场变化等重点议题。",
    "focus-cross-cultural": "聚焦跨文化交流、国际合作与多地区议题组织方式。",
}


class Command(BaseCommand):
    help = "Refresh homepage and shared public-facing copy for the published site."

    def handle(self, *args, **options):
        homepage = HomePage.objects.live().first()
        if not homepage:
            raise RuntimeError("HomePage not found.")

        for field, value in HOMEPAGE_FIELDS.items():
            setattr(homepage, field, value)
        homepage.seo_title = "大下科技"
        homepage.search_description = "大下科技，服务天下。"
        homepage.save_revision().publish()

        highlights = list(HomeHighlight.objects.filter(page=homepage).order_by("sort_order"))
        for item, spec in zip(highlights, HIGHLIGHT_SPECS):
            item.label, item.value, item.note = spec
            item.save()

        phases = list(HomeMigrationPhase.objects.filter(page=homepage).order_by("sort_order"))
        for item, spec in zip(phases, APPROACH_SPECS):
            item.phase, item.title, item.description = spec
            item.save()

        article_index = ArticleIndexPage.objects.live().filter(slug="articles").first()
        if article_index:
            article_index.intro = ARTICLE_INDEX_INTRO
            article_index.seo_title = "文章 | 大下科技"
            article_index.search_description = "聚焦研究观察、专题解读与活动相关内容。"
            article_index.save_revision().publish()

        for slug, values in STANDARD_PAGE_COPY.items():
            page = StandardPage.objects.live().filter(slug=slug).first()
            if page:
                page.intro = values["intro"]
                page.body = values["body"]
                if slug == "thinktank":
                    page.seo_title = "大下智库 | 大下科技"
                    page.search_description = "围绕重点议题、研究观察与合作主题组织公开表达和内容输出。"
                elif slug == "contact-us":
                    page.seo_title = "联系我们 | 大下科技"
                    page.search_description = "提供搜索、内容浏览、活动报名与业务页面的统一联系入口。"
                page.save_revision().publish()

        for slug, summary in MODULE_SUMMARIES.items():
            WorkspaceModule.objects.filter(slug=slug).update(summary=summary)

        self.stdout.write(self.style.SUCCESS("Public-facing content refreshed."))
