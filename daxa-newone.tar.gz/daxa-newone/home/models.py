from django.db import models

from modelcluster.fields import ParentalKey
from wagtail.admin.panels import FieldPanel, InlinePanel, MultiFieldPanel
from wagtail.fields import RichTextField
from wagtail.models import Orderable, Page


HOME_CHANNEL_CARD_COPY = {
    "thinktank": {
        "eyebrow": "Research",
        "summary": "围绕重点议题、研究输出与合作主题组织内容，形成面向公众与合作伙伴的研究入口。",
    },
    "articles": {
        "eyebrow": "Library",
        "summary": "集中呈现观察文章、资讯发布和专题内容，保持清晰的时间线与议题分类。",
    },
    "contact-us": {
        "eyebrow": "Contact",
        "summary": "提供搜索、会务与业务入口的统一联系页，便于快速进入合适的协作场景。",
    },
}


class HomePage(Page):
    max_count = 1
    parent_page_types = ["wagtailcore.Page"]
    subpage_types = [
        "sitecontent.StandardPage",
        "sitecontent.ArticleIndexPage",
        "meetings.MeetingRegistrationPage",
        "meetings.MeetingHandbookPage",
    ]

    hero_kicker = models.CharField(max_length=80, default="服务天下")
    hero_title = models.CharField(max_length=160, default="研究、数据、活动与能力建设，在同一平台协同呈现。")
    hero_intro = RichTextField(
        features=["bold", "italic", "link"],
        default=(
            "<p>大下科技围绕能源与气候、汽车与交通、国际合作等主题，持续提供研究内容、"
            "数据支持、活动组织与专题服务。</p>"
        ),
    )
    primary_cta_label = models.CharField(max_length=40, default="会议报名")
    primary_cta_url = models.URLField(blank=True, default="https://newone.daxa.ltd/conference-registration/")
    secondary_cta_label = models.CharField(max_length=40, default="查看频道")
    secondary_cta_url = models.URLField(blank=True, default="https://newone.daxa.ltd/workspace/")
    status_note = models.CharField(
        max_length=120,
        default="聚焦研究判断、数据服务、国际会议与专题合作。",
    )
    migration_summary = RichTextField(
        blank=True,
        features=["bold", "italic", "link"],
        default=(
            "<p>站点内容围绕研究频道、数据能力、活动组织和专题服务展开，"
            "让文章、页面与业务入口在同一内容体系中协同更新。</p>"
        ),
    )

    content_panels = Page.content_panels + [
        MultiFieldPanel(
            [
                FieldPanel("hero_kicker"),
                FieldPanel("hero_title"),
                FieldPanel("hero_intro"),
                FieldPanel("primary_cta_label"),
                FieldPanel("primary_cta_url"),
                FieldPanel("secondary_cta_label"),
                FieldPanel("secondary_cta_url"),
                FieldPanel("status_note"),
                FieldPanel("migration_summary"),
            ],
            heading="Hero",
        ),
        InlinePanel("highlights", label="关键指标"),
        InlinePanel("capabilities", label="核心能力"),
        InlinePanel("migration_phases", label="迁移阶段"),
    ]

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)

        from sitecontent.models import ArticleIndexPage, ArticlePage
        from workspace.models import WorkspaceModule

        workspace_hub = Page.objects.live().descendant_of(self).filter(slug="workspace").first()
        channel_pages = [
            page.specific
            for slug in ["thinktank", "articles", "contact-us"]
            for page in Page.objects.live().descendant_of(self).filter(slug=slug)[:1]
        ]
        context["channel_pages"] = channel_pages
        context["channel_cards"] = [
            {
                "page": item,
                "eyebrow": HOME_CHANNEL_CARD_COPY.get(item.slug, {}).get("eyebrow", "Channel"),
                "summary": HOME_CHANNEL_CARD_COPY.get(item.slug, {}).get(
                    "summary",
                    item.intro or "这一页汇总了对应主题的核心内容与业务入口。",
                ),
            }
            for item in channel_pages
        ]
        if workspace_hub:
            context["workspace_channel_pages"] = [
                page.specific
                for page in Page.objects.live().child_of(workspace_hub).order_by("path")
            ]
        else:
            context["workspace_channel_pages"] = []
        context["workspace_hub"] = workspace_hub
        article_index = ArticleIndexPage.objects.live().filter(slug="articles").first()
        context["article_index"] = article_index
        context["latest_articles"] = ArticlePage.objects.live().order_by("-date", "-first_published_at")[:3]
        context["workspace_modules"] = WorkspaceModule.objects.order_by("title")[:6]
        return context


class HomeHighlight(Orderable):
    page = ParentalKey(HomePage, related_name="highlights", on_delete=models.CASCADE)
    label = models.CharField(max_length=60)
    value = models.CharField(max_length=60)
    note = models.CharField(max_length=100, blank=True)

    panels = [
        FieldPanel("label"),
        FieldPanel("value"),
        FieldPanel("note"),
    ]


class HomeCapability(Orderable):
    page = ParentalKey(HomePage, related_name="capabilities", on_delete=models.CASCADE)
    eyebrow = models.CharField(max_length=40)
    title = models.CharField(max_length=80)
    description = models.TextField()

    panels = [
        FieldPanel("eyebrow"),
        FieldPanel("title"),
        FieldPanel("description"),
    ]


class HomeMigrationPhase(Orderable):
    page = ParentalKey(HomePage, related_name="migration_phases", on_delete=models.CASCADE)
    phase = models.CharField(max_length=40)
    title = models.CharField(max_length=100)
    description = models.TextField()

    panels = [
        FieldPanel("phase"),
        FieldPanel("title"),
        FieldPanel("description"),
    ]
