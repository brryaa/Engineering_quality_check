from django.db import migrations


WORKSPACE_PAGE_SPECS = [
    {
        "slug": "research-insights",
        "title": "研究与前沿资讯",
        "intro": "承接原 /sp/ 的 Research & Insights 频道，用于汇总观察文章、行业跟踪和专题判断。",
        "body": (
            "<p>这一频道对应旧 <code>/sp/</code> 站点中的 <strong>Research &amp; Insights</strong>，"
            "会逐步承接研究文章、行业简报与阶段性判断。</p>"
            "<p>当前优先迁移的内容方向包括：</p>"
            "<ul>"
            "<li>能源与气候变化</li>"
            "<li>汽车与交通</li>"
            "<li>跨文化交流与国际合作</li>"
            "</ul>"
        ),
    },
    {
        "slug": "capabilities",
        "title": "能力建设",
        "intro": "对应旧 /sp/ 的 Capabilities 频道，后续用于承接训练营、工作坊和方法论服务。",
        "body": (
            "<p>这一频道用于整理旧子站里的能力建设类内容，把原本分散在主题菜单下的说明改成可持续维护的页面结构。</p>"
            "<p>目前识别到的重点包括训练工作坊、项目咨询、标准制定与方法库沉淀。</p>"
        ),
    },
    {
        "slug": "data-analytics",
        "title": "数据与调研",
        "intro": "承接原 /sp/ 的 Data & Analytics 频道，用来统一管理数据库、调研和订阅产品方向。",
        "body": (
            "<p>这一频道会承接原 <strong>Data &amp; Analytics</strong> 下的说明页与产品化入口，"
            "包括金融数据、信用评级、风险管理与 ESG 解决方案等方向。</p>"
            "<p>现阶段先建立频道页，后续再根据实际可运营内容拆成更细的产品页面。</p>"
        ),
    },
    {
        "slug": "events",
        "title": "活动",
        "intro": "对应旧 /sp/ 的 Events 频道，统一承接国际会议、高端论坛、闭门会和会务流程。",
        "body": (
            "<p>旧子站把活动、会务、报名和资讯拆在多个位置；新站会把这些内容统一到活动频道和会议模块中。</p>"
            "<p>当前最先落地的是会议报名页与会议手册，后续活动页会继续并入这个频道。</p>"
        ),
    },
]

WORKSPACE_MODULE_SPECS = [
    {
        "slug": "industry-reports",
        "title": "行业报告与政策建议",
        "status": "mapped",
        "summary": "来自 /sp/ 首页的核心能力项，后续会沉淀为研究专题页与可复用服务说明。",
    },
    {
        "slug": "executive-forums",
        "title": "国际会议与高端论坛",
        "status": "live-foundation",
        "summary": "会务流程已在新站先落地，后续继续吸收旧 /sp/ 活动频道内容。",
    },
    {
        "slug": "training-workshops",
        "title": "能力建设训练与工作坊",
        "status": "mapped",
        "summary": "对应旧 /sp/ 的能力建设方向，后续整理为课程、工作坊与服务流程页面。",
    },
    {
        "slug": "project-consulting",
        "title": "项目咨询",
        "status": "planned",
        "summary": "从旧 /sp/ 首页识别出的服务方向，后续并入统一咨询与合作入口。",
    },
    {
        "slug": "standards-development",
        "title": "标准制定",
        "status": "planned",
        "summary": "保留旧 /sp/ 里的服务线索，后续根据实际材料扩展为专题与能力页。",
    },
    {
        "slug": "database-subscription",
        "title": "数据库订阅",
        "status": "mapped",
        "summary": "承接旧站“大下数据库 / Data & Analytics”方向，后续拆为更细的数据产品入口。",
    },
    {
        "slug": "focus-energy-climate",
        "title": "聚焦领域：能源与气候变化",
        "status": "mapped",
        "summary": "来自 /sp/ 首页的三大聚焦领域之一，可作为后续文章与专题聚合轴。",
    },
    {
        "slug": "focus-auto-transport",
        "title": "聚焦领域：汽车与交通",
        "status": "mapped",
        "summary": "对应旧子站重点领域，可继续吸收现有汽车研究文章和专题活动。",
    },
    {
        "slug": "focus-cross-cultural",
        "title": "聚焦领域：跨文化交流与国际合作",
        "status": "mapped",
        "summary": "保留旧 /sp/ 的国际合作方向，后续作为研究与活动内容的组织维度。",
    },
]

LEGACY_ROUTE_SPECS = [
    ("/sp/", "/", "旧 /sp/ 站点首页在新站由首页与频道页共同承接。"),
    ("/sp/index.php/sample-page/", "/thinktank/", "旧 /sp/ Think Tank 页面先并入新智库频道。"),
    ("/sp/index.php/dx-think-tank/", "/thinktank/", "旧 /sp/ 空白占位页并入新智库频道。"),
    ("/sp/index.php/research-insights/", "/research-insights/", "旧 /sp/ Research & Insights 频道映射。"),
    ("/sp/index.php/capabilities/", "/capabilities/", "旧 /sp/ Capabilities 频道映射。"),
    ("/sp/index.php/data-analytics/", "/data-analytics/", "旧 /sp/ Data & Analytics 频道映射。"),
    ("/sp/index.php/events/", "/events/", "旧 /sp/ Events 频道映射。"),
    ("/sp/index.php/data-analytics/risk-management/", "/data-analytics/", "旧 /sp/ 二级菜单暂时收拢到数据与调研频道。"),
    ("/sp/index.php/data-analytics/credit-ratings/", "/data-analytics/", "旧 /sp/ 二级菜单暂时收拢到数据与调研频道。"),
    ("/sp/index.php/data-analytics/financial-data/", "/data-analytics/", "旧 /sp/ 二级菜单暂时收拢到数据与调研频道。"),
    ("/sp/index.php/data-analytics/esg-solutions/", "/data-analytics/", "旧 /sp/ 二级菜单暂时收拢到数据与调研频道。"),
    ("/sp/index.php/capabilities/asset-management/", "/capabilities/", "旧 /sp/ 二级菜单暂时收拢到能力建设频道。"),
    ("/sp/index.php/capabilities/investment-banking/", "/capabilities/", "旧 /sp/ 二级菜单暂时收拢到能力建设频道。"),
]


def seed_workspace_structure(apps, schema_editor):
    WorkspaceModule = apps.get_model("workspace", "WorkspaceModule")
    LegacyRoute = apps.get_model("workspace", "LegacyRoute")

    for spec in WORKSPACE_MODULE_SPECS:
        WorkspaceModule.objects.update_or_create(
            slug=spec["slug"],
            defaults={
                "title": spec["title"],
                "status": spec["status"],
                "summary": spec["summary"],
            },
        )

    for source_path, destination_path, notes in LEGACY_ROUTE_SPECS:
        LegacyRoute.objects.update_or_create(
            source_path=source_path,
            defaults={
                "destination_path": destination_path,
                "notes": notes,
            },
        )


def unseed_workspace_structure(apps, schema_editor):
    WorkspaceModule = apps.get_model("workspace", "WorkspaceModule")
    LegacyRoute = apps.get_model("workspace", "LegacyRoute")

    WorkspaceModule.objects.filter(slug__in=[item["slug"] for item in WORKSPACE_MODULE_SPECS]).delete()
    LegacyRoute.objects.filter(source_path__in=[item[0] for item in LEGACY_ROUTE_SPECS]).delete()


class Migration(migrations.Migration):
    dependencies = [
        ("workspace", "0001_initial"),
        ("sitecontent", "0001_initial"),
        ("home", "0005_alter_homepage_primary_cta_label_and_more"),
    ]

    operations = [
        migrations.RunPython(seed_workspace_structure, unseed_workspace_structure),
    ]
