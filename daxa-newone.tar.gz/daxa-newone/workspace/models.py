from django.db import models

from wagtail.admin.panels import FieldPanel
from wagtail.snippets.models import register_snippet


@register_snippet
class LegacyRoute(models.Model):
    source_path = models.CharField(max_length=255, unique=True)
    destination_path = models.CharField(max_length=255)
    notes = models.TextField(blank=True)

    panels = [
        FieldPanel("source_path"),
        FieldPanel("destination_path"),
        FieldPanel("notes"),
    ]

    def __str__(self):
        return f"{self.source_path} -> {self.destination_path}"


@register_snippet
class WorkspaceModule(models.Model):
    slug = models.SlugField(unique=True)
    title = models.CharField(max_length=80)
    status = models.CharField(max_length=40, default="planned")
    summary = models.TextField()

    panels = [
        FieldPanel("slug"),
        FieldPanel("title"),
        FieldPanel("status"),
        FieldPanel("summary"),
    ]

    def __str__(self):
        return self.title
