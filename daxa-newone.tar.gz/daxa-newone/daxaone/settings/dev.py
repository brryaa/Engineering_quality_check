from .base import *  # noqa: F403, F401

DEBUG = True
SECRET_KEY = "dev-only-secret-key"
ALLOWED_HOSTS = ["*"]
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

DATABASES["default"] = {  # noqa: F405
    "ENGINE": "django.db.backends.sqlite3",
    "NAME": BASE_DIR / "db.sqlite3",  # noqa: F405
}

CACHES["default"] = {  # noqa: F405
    "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
    "LOCATION": "daxaone-dev",
}

try:
    from .local import *  # noqa: F403, F401
except ImportError:
    pass
